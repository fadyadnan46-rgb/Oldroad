
import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { User, UserRole } from '../types';

interface NavbarProps {
  user: User | null;
  logout: () => void;
}

const Navbar: React.FC<NavbarProps> = ({ user, logout }) => {
  const navigate = useNavigate();
  const isStaff = user?.role === UserRole.ADMIN || user?.role === UserRole.SALES;
  const isAdmin = user?.role === UserRole.ADMIN;

  return (
    <nav className="sticky top-0 z-50 bg-white/80 dark:bg-slate-900/80 backdrop-blur-md border-b border-slate-200 dark:border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16 items-center">
          <div className="flex items-center gap-8">
            <Link to="/" className="flex items-center gap-2">
              <i className="fa-solid fa-car-side text-accent text-2xl"></i>
              <span className="font-serif text-2xl font-bold tracking-tight text-primary dark:text-white">
                OldRoad <span className="text-accent">Auto</span>
              </span>
            </Link>
            
            <div className="hidden md:flex space-x-6 items-center">
              <Link to="/" className="text-slate-600 dark:text-slate-300 hover:text-accent font-medium">Home</Link>
              <Link to="/inventory" className="text-slate-600 dark:text-slate-300 hover:text-accent font-medium">Inventory</Link>
              <Link to="/trade-in" className="text-slate-600 dark:text-slate-300 hover:text-accent font-medium">Trade-In</Link>
              
              {isStaff && (
                <>
                  <Link to="/manage-trades" className="text-emerald-600 dark:text-emerald-400 hover:text-emerald-700 font-bold flex items-center gap-1">
                    <i className="fa-solid fa-clipboard-list text-sm"></i>
                    Manage Trades
                  </Link>
                  <Link to="/contracts" className="text-blue-600 dark:text-blue-400 hover:text-blue-700 font-bold flex items-center gap-1">
                    <i className="fa-solid fa-file-signature text-sm"></i>
                    Contracts
                  </Link>
                </>
              )}

              {isAdmin && (
                <Link to="/dispatch" className="text-orange-600 dark:text-orange-400 hover:text-orange-700 font-bold flex items-center gap-1">
                  <i className="fa-solid fa-truck-ramp-box text-sm"></i>
                  Dispatch
                </Link>
              )}

              <Link to="/about" className="text-slate-600 dark:text-slate-300 hover:text-accent font-medium">About Us</Link>
            </div>
          </div>

          <div className="flex items-center gap-4">
            {user ? (
              <div className="flex items-center gap-4">
                <Link 
                  to="/dashboard" 
                  className="hidden sm:block text-slate-600 dark:text-slate-300 hover:text-accent font-medium"
                >
                  Dashboard
                </Link>
                <button 
                  onClick={() => { logout(); navigate('/'); }}
                  className="bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 px-4 py-2 rounded-lg hover:bg-slate-200 transition-colors"
                >
                  Sign Out
                </button>
              </div>
            ) : (
              <div className="flex items-center gap-3">
                <Link 
                  to="/auth" 
                  className="text-slate-600 dark:text-slate-300 hover:text-accent font-medium px-2"
                >
                  Sign In
                </Link>
                <Link 
                  to="/auth" 
                  className="bg-primary text-white px-6 py-2 rounded-lg hover:bg-slate-800 transition-shadow shadow-md"
                >
                  Join Us
                </Link>
              </div>
            )}
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
