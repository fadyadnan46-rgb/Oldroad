
import React from 'react';
import { Link } from 'react-router-dom';

const Footer: React.FC = () => {
  return (
    <footer className="bg-primary text-slate-300 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12">
          <div className="space-y-4">
            <h3 className="font-serif text-2xl font-bold text-white">OldRoad <span className="text-accent">Auto</span></h3>
            <p className="text-sm leading-relaxed">
              Premium automotive solutions for the modern collector. Specializing in high-end inventory and seamless trade-ins.
            </p>
            <div className="flex gap-4">
              <a href="#" className="hover:text-accent"><i className="fa-brands fa-instagram text-xl"></i></a>
              <a href="#" className="hover:text-accent"><i className="fa-brands fa-facebook text-xl"></i></a>
              <a href="#" className="hover:text-accent"><i className="fa-brands fa-linkedin text-xl"></i></a>
            </div>
          </div>

          <div>
            <h4 className="font-bold text-white mb-4">Quick Links</h4>
            <ul className="space-y-2 text-sm">
              <li><Link to="/about" className="hover:text-accent transition-colors">About Us</Link></li>
              <li><Link to="/inventory" className="hover:text-accent transition-colors">Our Inventory</Link></li>
              <li><Link to="/trade-in" className="hover:text-accent transition-colors">Trade Your Vehicle</Link></li>
              <li><a href="#" className="hover:text-accent transition-colors">Privacy Policy</a></li>
              <li><a href="#" className="hover:text-accent transition-colors">Terms of Service</a></li>
            </ul>
          </div>

          <div>
            <h4 className="font-bold text-white mb-4">Our Locations</h4>
            <div className="space-y-4 text-sm">
              <div>
                <p className="font-medium text-white">Main Showroom</p>
                <p>123 Auto Row, Toronto, ON</p>
                <p>+1 (555) 0100</p>
              </div>
              <div>
                <p className="font-medium text-white">East Warehouse</p>
                <p>456 Industrial Pkwy, Oshawa, ON</p>
                <p>+1 (555) 0200</p>
              </div>
            </div>
          </div>

          <div>
            <h4 className="font-bold text-white mb-4">Newsletter</h4>
            <p className="text-sm mb-4">Stay updated with our newest inventory.</p>
            <form className="flex gap-2">
              <input 
                type="email" 
                placeholder="Email address" 
                className="bg-slate-800 border-none rounded-lg px-4 py-2 w-full focus:ring-2 focus:ring-accent outline-none"
              />
              <button className="bg-accent text-primary px-4 py-2 rounded-lg font-bold hover:bg-amber-500 transition-colors">
                <i className="fa-solid fa-paper-plane"></i>
              </button>
            </form>
          </div>
        </div>
        
        <div className="border-t border-slate-800 mt-12 pt-8 text-center text-xs">
          <p>&copy; {new Date().getFullYear()} OldRoad Auto Management Systems. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
