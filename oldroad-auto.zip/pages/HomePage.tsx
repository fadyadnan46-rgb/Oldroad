
import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { generateDreamCarImage } from '../geminiService';

const HomePage: React.FC = () => {
  const [dreamPrompt, setDreamPrompt] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedCar, setGeneratedCar] = useState<string | null>(null);

  const handleGenerateDreamCar = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!dreamPrompt.trim()) return;
    setIsGenerating(true);
    const result = await generateDreamCarImage(dreamPrompt);
    setGeneratedCar(result);
    setIsGenerating(false);
  };

  return (
    <div className="space-y-20">
      {/* Hero Section - Improved Robustness */}
      <section className="relative h-[85vh] flex items-center bg-primary overflow-hidden">
        {/* Background Image with Fallback and Overlay */}
        <div 
          className="absolute inset-0 z-0 bg-cover bg-center transition-opacity duration-1000"
          style={{ 
            backgroundImage: `url('https://images.unsplash.com/photo-1542362567-b05503f3f5f4?auto=format&fit=crop&q=80&w=1920&h=1080')`,
            backgroundColor: '#0f172a' // Dark slate fallback
          }}
        >
          {/* Dark Overlay Gradient for guaranteed readability */}
          <div className="absolute inset-0 bg-gradient-to-r from-black/80 via-black/40 to-transparent"></div>
        </div>

        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full">
          <div className="max-w-3xl space-y-8 animate-in fade-in slide-in-from-left-8 duration-1000">
            <div className="space-y-4">
              <span className="inline-block text-accent font-black uppercase tracking-[0.3em] text-xs py-1 px-3 bg-accent/10 rounded-full border border-accent/20">
                Newest Arrivals
              </span>
              <h1 className="text-5xl md:text-7xl lg:text-8xl font-serif text-white leading-[1.1] drop-shadow-2xl">
                Drive the Road <br /> 
                <span className="text-white/90 italic">Less Traveled.</span>
              </h1>
            </div>
            
            <p className="text-lg md:text-xl text-slate-300 max-w-xl leading-relaxed drop-shadow-md">
              Discover a curated collection of premium pre-owned vehicles, thoroughly inspected and ready for your next adventure.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-5 pt-4">
              <Link 
                to="/inventory" 
                className="bg-accent text-primary px-10 py-5 rounded-2xl font-bold text-lg hover:bg-amber-500 transition-all text-center shadow-2xl shadow-accent/20 active:scale-95"
              >
                Browse Inventory
              </Link>
              <Link 
                to="/trade-in" 
                className="bg-white/10 backdrop-blur-xl border border-white/20 text-white px-10 py-5 rounded-2xl font-bold text-lg hover:bg-white/20 transition-all text-center active:scale-95"
              >
                Trade Your Vehicle
              </Link>
            </div>
          </div>
        </div>

        {/* Decorative element */}
        <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-slate-50 dark:from-slate-900 to-transparent z-20"></div>
      </section>

      {/* Featured Categories */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center space-y-4 mb-16">
          <h2 className="text-4xl font-serif font-bold text-primary dark:text-white">Search by Lifestyle</h2>
          <div className="w-20 h-1 bg-accent mx-auto rounded-full"></div>
          <p className="text-slate-500 text-lg">Whatever your journey, we have the perfect fit.</p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {[
            { name: 'SUVs', icon: 'fa-shuttle-van', img: 'https://images.unsplash.com/photo-1519641471654-76ce0107ad1b?auto=format&fit=crop&q=80&w=600&h=400' },
            { name: 'Trucks', icon: 'fa-truck-pickup', img: 'https://images.unsplash.com/photo-1533473359331-0135ef1b58bf?auto=format&fit=crop&q=80&w=600&h=400' },
            { name: 'Sedans', icon: 'fa-car', img: 'https://images.unsplash.com/photo-1549317661-bd32c8ce0db2?auto=format&fit=crop&q=80&w=600&h=400' }
          ].map((cat) => (
            <Link 
              key={cat.name}
              to={`/inventory?category=${cat.name}`}
              className="group relative h-80 rounded-[2.5rem] overflow-hidden shadow-xl"
            >
              <img src={cat.img} alt={cat.name} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" />
              <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/30 to-transparent flex flex-col justify-end p-8">
                <i className={`fa-solid ${cat.icon} text-accent text-3xl mb-3`}></i>
                <h3 className="text-3xl font-bold text-white mb-1">{cat.name}</h3>
                <p className="text-slate-400 text-sm font-medium translate-y-4 opacity-0 group-hover:translate-y-0 group-hover:opacity-100 transition-all duration-300">Explore models &rarr;</p>
              </div>
            </Link>
          ))}
        </div>
      </section>

      {/* Dream Car Studio (AI Generation) */}
      <section className="bg-slate-900 py-32 overflow-hidden relative">
        <div className="absolute top-0 left-0 w-full h-full overflow-hidden pointer-events-none opacity-20">
          <div className="absolute top-[-10%] right-[-10%] w-[50%] h-[50%] bg-accent/20 blur-[120px] rounded-full"></div>
          <div className="absolute bottom-[-10%] left-[-10%] w-[40%] h-[40%] bg-blue-500/10 blur-[120px] rounded-full"></div>
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid grid-cols-1 lg:grid-cols-2 gap-20 items-center">
          <div className="space-y-10 relative z-10">
            <div className="space-y-4">
              <span className="text-accent font-black uppercase tracking-[0.4em] text-xs">Innovation Lab</span>
              <h2 className="text-4xl md:text-6xl font-serif font-bold text-white leading-tight">Visualize Your <br /> Dream Vehicle.</h2>
            </div>
            <p className="text-slate-400 text-lg leading-relaxed">
              Can't find exactly what you're looking for? Describe your ultimate concept car and our AI will render it for you in high definition using our proprietary Gemini integration.
            </p>
            <form onSubmit={handleGenerateDreamCar} className="space-y-6">
              <div className="relative group">
                <textarea 
                  placeholder="e.g. A futuristic electric supercar in matte obsidian black with glowing cyan accents, driving through a neon-lit city at night."
                  className="w-full bg-white/5 border border-white/10 rounded-3xl p-8 text-white outline-none focus:ring-2 focus:ring-accent transition-all h-40 resize-none text-lg group-hover:border-white/20"
                  value={dreamPrompt}
                  onChange={(e) => setDreamPrompt(e.target.value)}
                />
                <div className="absolute bottom-4 right-6 text-slate-500 text-xs font-mono">
                  {dreamPrompt.length} characters
                </div>
              </div>
              <button 
                type="submit"
                disabled={isGenerating || !dreamPrompt.trim()}
                className="w-full bg-accent text-primary py-5 rounded-[1.5rem] font-bold text-xl hover:bg-amber-500 transition-all flex items-center justify-center gap-3 disabled:opacity-50 shadow-xl shadow-accent/10 active:scale-[0.98]"
              >
                {isGenerating ? (
                  <>
                    <i className="fa-solid fa-spinner fa-spin"></i>
                    Designing Assets...
                  </>
                ) : (
                  <>
                    <i className="fa-solid fa-wand-magic-sparkles"></i>
                    Generate Concept
                  </>
                )}
              </button>
            </form>
          </div>
          <div className="relative">
            {generatedCar ? (
              <div className="animate-in fade-in zoom-in duration-700">
                <div className="relative group">
                  <img src={generatedCar} className="rounded-[3rem] shadow-[0_35px_60px_-15px_rgba(0,0,0,0.6)] border border-white/10 w-full aspect-video object-cover" alt="Generated Dream Car" />
                  <div className="absolute inset-0 rounded-[3rem] ring-1 ring-inset ring-white/20 pointer-events-none"></div>
                </div>
                <button 
                  onClick={() => setGeneratedCar(null)}
                  className="mt-8 text-slate-400 text-sm font-bold hover:text-white transition-colors flex items-center gap-2 mx-auto"
                >
                  <i className="fa-solid fa-rotate-left"></i> Start New Design
                </button>
              </div>
            ) : (
              <div className="aspect-video bg-white/[0.03] border-2 border-white/5 border-dashed rounded-[3rem] flex flex-col items-center justify-center text-slate-600 transition-all group hover:bg-white/[0.05] hover:border-white/10 cursor-default">
                <div className={`w-24 h-24 rounded-full bg-white/5 flex items-center justify-center mb-6 transition-all group-hover:scale-110 ${isGenerating ? 'animate-pulse bg-accent/10' : ''}`}>
                  <i className={`fa-solid fa-car-rear text-5xl ${isGenerating ? 'text-accent' : 'text-slate-700'}`}></i>
                </div>
                <p className="font-bold text-lg tracking-wide uppercase">{isGenerating ? 'Rendering Concept...' : 'Your vision awaits generation.'}</p>
                <p className="text-sm mt-2 opacity-50 px-8 text-center">Enter a prompt on the left to activate the visualizer.</p>
              </div>
            )}
            <div className="absolute -bottom-6 -right-6 bg-accent p-6 rounded-3xl border border-white/10 shadow-2xl hidden lg:block animate-bounce-slow">
              <p className="text-primary font-black text-sm uppercase tracking-tighter">Powered by Gemini Visual</p>
            </div>
          </div>
        </div>
      </section>

      {/* Trust Section */}
      <section className="bg-slate-100 dark:bg-slate-800 py-32 rounded-[4rem] mx-4">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid grid-cols-1 md:grid-cols-2 gap-20 items-center">
          <div className="space-y-10">
            <div className="space-y-4">
              <h2 className="text-4xl md:text-5xl font-serif font-bold leading-tight text-primary dark:text-white">Professionalism at every <br /> kilometer.</h2>
              <div className="w-16 h-1.5 bg-accent rounded-full"></div>
            </div>
            <p className="text-xl text-slate-600 dark:text-slate-400 leading-relaxed">
              At OldRoad Auto, we believe buying a car should be as thrilling as driving one. Our transparent trade-in process and rigorous vehicle vetting ensure peace of mind.
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-10 pt-4">
              <div className="space-y-3 p-6 bg-white dark:bg-slate-900 rounded-3xl shadow-sm border border-slate-200 dark:border-slate-700">
                <i className="fa-solid fa-file-contract text-accent text-3xl"></i>
                <h4 className="font-bold text-xl">Full History</h4>
                <p className="text-sm text-slate-500 leading-relaxed">Every car comes with a verified Carfax report and full maintenance logs.</p>
              </div>
              <div className="space-y-3 p-6 bg-white dark:bg-slate-900 rounded-3xl shadow-sm border border-slate-200 dark:border-slate-700">
                <i className="fa-solid fa-screwdriver-wrench text-accent text-3xl"></i>
                <h4 className="font-bold text-xl">150pt Inspection</h4>
                <p className="text-sm text-slate-500 leading-relaxed">No vehicle leaves our showroom without a deep internal health check.</p>
              </div>
            </div>
          </div>
          <div className="relative group">
            <img 
              src="https://images.unsplash.com/photo-1486006396113-c7b3df928550?auto=format&fit=crop&q=80&w=800&h=600" 
              alt="Quality Check" 
              className="rounded-[3rem] shadow-[0_30px_60px_-15px_rgba(0,0,0,0.3)] relative z-10 transition-transform duration-500 group-hover:scale-[1.02]"
            />
            <div className="absolute -bottom-10 -left-10 bg-accent p-10 rounded-[2rem] shadow-2xl z-20 hidden lg:block transform -rotate-3 group-hover:rotate-0 transition-transform">
              <p className="text-primary font-black text-5xl mb-1">100%</p>
              <p className="text-primary/70 text-sm font-bold uppercase tracking-widest">Customer Trust</p>
            </div>
          </div>
        </div>
      </section>
      
      <style>{`
        @keyframes bounce-slow {
          0%, 100% { transform: translateY(-5%); }
          50% { transform: translateY(0); }
        }
        .animate-bounce-slow {
          animation: bounce-slow 4s infinite ease-in-out;
        }
      `}</style>
    </div>
  );
};

export default HomePage;
