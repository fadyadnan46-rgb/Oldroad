
import React, { useState, useEffect, useCallback } from 'react';
import { useSearchParams, Link } from 'react-router-dom';
import { MOCK_VEHICLES, PLACEHOLDER_IMAGE } from '../constants';
import { Vehicle, User, VehicleStatus } from '../types';

interface InventoryPageProps {
  user: User | null;
}

type ModalView = 'details' | 'booking-success' | 'inquiry-success' | 'auth-required';

const BODY_STYLES = [
  { id: 'All', label: 'All Vehicles', icon: 'fa-car-rear' },
  { id: 'SUV', label: 'SUVs', icon: 'fa-shuttle-van' },
  { id: 'Truck', label: 'Trucks', icon: 'fa-truck-pickup' },
  { id: 'Sedan', label: 'Sedans', icon: 'fa-car' },
  { id: 'EV', label: 'Electric', icon: 'fa-bolt' }
];

const InventoryPage: React.FC<InventoryPageProps> = ({ user }) => {
  const [searchParams, setSearchParams] = useSearchParams();
  const [search, setSearch] = useState('');
  const [selectedVehicle, setSelectedVehicle] = useState<Vehicle | null>(null);
  const [activeImageIndex, setActiveImageIndex] = useState(0);
  const [modalView, setModalView] = useState<ModalView>('details');
  const [isProcessing, setIsProcessing] = useState(false);
  const [isZoomed, setIsZoomed] = useState(false);
  const [imageTransition, setImageTransition] = useState(true);

  // Active category derived from search params
  const categoryParam = searchParams.get('category');
  
  // Normalize categories (handles plurals from homepage links)
  const activeCategory = categoryParam 
    ? (categoryParam.endsWith('s') ? categoryParam.slice(0, -1) : categoryParam)
    : 'All';

  const readyVehicles = MOCK_VEHICLES.filter(v => v.status === VehicleStatus.READY);

  const filtered = readyVehicles.filter(v => {
    const matchesSearch = `${v.year} ${v.make} ${v.model}`.toLowerCase().includes(search.toLowerCase());
    const matchesCategory = activeCategory === 'All' 
      ? true 
      : activeCategory === 'EV' 
        ? v.fuelType === 'EV' 
        : v.bodyStyle === activeCategory;
    
    return matchesSearch && matchesCategory;
  });

  const handleCategoryChange = (cat: string) => {
    if (cat === 'All') {
      searchParams.delete('category');
    } else {
      searchParams.set('category', cat);
    }
    setSearchParams(searchParams);
  };

  const closeModal = useCallback(() => {
    setSelectedVehicle(null);
    setModalView('details');
    setActiveImageIndex(0);
    setIsZoomed(false);
  }, []);

  const handleNextImage = useCallback((e?: React.MouseEvent) => {
    e?.stopPropagation();
    if (!selectedVehicle || selectedVehicle.images.length <= 1) return;
    setImageTransition(false);
    setTimeout(() => {
      setActiveImageIndex((prev) => (prev + 1) % selectedVehicle.images.length);
      setImageTransition(true);
    }, 50);
  }, [selectedVehicle]);

  const handlePrevImage = useCallback((e?: React.MouseEvent) => {
    e?.stopPropagation();
    if (!selectedVehicle || selectedVehicle.images.length <= 1) return;
    setImageTransition(false);
    setTimeout(() => {
      setActiveImageIndex((prev) => (prev - 1 + selectedVehicle.images.length) % selectedVehicle.images.length);
      setImageTransition(true);
    }, 50);
  }, [selectedVehicle]);

  // Keyboard Navigation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (!selectedVehicle) return;
      
      if (e.key === 'ArrowRight') handleNextImage();
      if (e.key === 'ArrowLeft') handlePrevImage();
      if (e.key === 'Escape') {
        if (isZoomed) setIsZoomed(false);
        else closeModal();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [selectedVehicle, handleNextImage, handlePrevImage, closeModal, isZoomed]);

  const handleBookTestDrive = () => {
    if (!user) {
      setModalView('auth-required');
      return;
    }
    setIsProcessing(true);
    setTimeout(() => {
      setIsProcessing(false);
      setModalView('booking-success');
    }, 800);
  };

  const handleInquireNow = () => {
    if (!user) {
      setModalView('auth-required');
      return;
    }
    setIsProcessing(true);
    setTimeout(() => {
      setIsProcessing(false);
      setModalView('inquiry-success');
    }, 800);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="flex flex-col md:flex-row justify-between items-end gap-6 mb-8">
        <div className="space-y-2">
          <h1 className="text-4xl font-serif font-bold">Current Inventory</h1>
          <p className="text-slate-500">Showing {filtered.length} premium vehicles.</p>
        </div>
        <div className="w-full md:w-96 relative">
          <i className="fa-solid fa-magnifying-glass absolute left-4 top-1/2 -translate-y-1/2 text-slate-400"></i>
          <input 
            type="text" 
            placeholder="Search make, model, or year..." 
            className="w-full pl-12 pr-4 py-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 focus:ring-2 focus:ring-accent outline-none transition-all shadow-sm"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
      </div>

      {/* Body Style Filter Bar */}
      <div className="flex flex-wrap gap-2 mb-12 pb-4 border-b border-slate-100 dark:border-slate-800">
        {BODY_STYLES.map((style) => (
          <button
            key={style.id}
            onClick={() => handleCategoryChange(style.id)}
            className={`flex items-center gap-2 px-6 py-2.5 rounded-full font-bold text-sm transition-all active:scale-95 ${
              activeCategory === style.id 
                ? 'bg-accent text-primary shadow-lg shadow-accent/20' 
                : 'bg-white dark:bg-slate-900 text-slate-500 border border-slate-200 dark:border-slate-800 hover:border-accent hover:text-accent'
            }`}
          >
            <i className={`fa-solid ${style.icon} text-xs`}></i>
            {style.label}
          </button>
        ))}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {filtered.map(v => (
          <div key={v.id} className="group bg-white dark:bg-slate-900 rounded-2xl overflow-hidden border border-slate-200 dark:border-slate-800 shadow-sm hover:shadow-xl transition-all duration-300">
            <div className="relative h-64 overflow-hidden">
              <img 
                src={v.images && v.images.length > 0 ? v.images[0] : PLACEHOLDER_IMAGE} 
                alt={v.model} 
                className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110" 
              />
              <div className="absolute top-4 left-4 flex gap-2">
                <span className="bg-accent text-primary text-[10px] font-bold px-3 py-1 rounded-full uppercase tracking-tighter shadow-md">{v.fuelType}</span>
                {v.carfaxUrl && (
                  <span className="bg-blue-600 text-white text-[10px] font-bold px-3 py-1 rounded-full uppercase tracking-tighter shadow-md">Carfax</span>
                )}
              </div>
              <div className="absolute bottom-4 right-4 bg-white/95 dark:bg-slate-800/95 backdrop-blur-sm px-4 py-2 rounded-xl font-bold shadow-lg text-primary dark:text-white">
                ${v.price.toLocaleString()}
              </div>
            </div>
            
            <div className="p-6 space-y-4">
              <div>
                <h3 className="text-xl font-bold group-hover:text-accent transition-colors">{v.year} {v.make} {v.model}</h3>
                <p className="text-slate-500 text-sm capitalize">{v.bodyStyle} &bull; {v.trim} &bull; {v.km.toLocaleString()} KM</p>
              </div>

              <div className="flex flex-wrap gap-2">
                {v.features.safety.slice(0, 2).map(f => (
                  <span key={f} className="text-[10px] uppercase font-bold text-slate-400 border border-slate-200 dark:border-slate-700 px-2 py-1 rounded">
                    {f}
                  </span>
                ))}
              </div>

              <div className="pt-4 flex gap-3">
                <button 
                  onClick={() => setSelectedVehicle(v)}
                  className="flex-1 bg-primary dark:bg-slate-800 text-white py-3 rounded-xl font-bold hover:bg-slate-800 dark:hover:bg-slate-700 transition-all active:scale-95"
                >
                  View Details
                </button>
                <button className={`bg-slate-100 dark:bg-slate-800 p-3 rounded-xl hover:text-accent transition-colors ${!user ? 'opacity-50 cursor-not-allowed' : ''}`} title="Add to Favorites" disabled={!user}>
                  <i className="fa-regular fa-heart text-xl"></i>
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {filtered.length === 0 && (
        <div className="text-center py-24 bg-slate-100 dark:bg-slate-800 rounded-[3rem] border-2 border-dashed border-slate-200 dark:border-slate-700">
          <i className="fa-solid fa-car-on text-6xl text-slate-300 mb-6"></i>
          <h3 className="text-2xl font-bold mb-2">No vehicles found</h3>
          <p className="text-slate-500 max-w-sm mx-auto">We couldn't find any {activeCategory !== 'All' ? activeCategory : ''} vehicles matching your current search. Try clearing your filters.</p>
          <button 
            onClick={() => handleCategoryChange('All')}
            className="mt-8 text-accent font-bold hover:underline underline-offset-4"
          >
            Show all available inventory
          </button>
        </div>
      )}

      {/* Fullscreen Zoom Lightbox */}
      {isZoomed && selectedVehicle && selectedVehicle.images.length > 0 && (
        <div className="fixed inset-0 z-[100] bg-black/95 flex items-center justify-center p-4 animate-in fade-in duration-300">
          <button 
            onClick={() => setIsZoomed(false)}
            className="absolute top-8 left-8 text-white text-4xl hover:text-accent transition-colors z-[110]"
          >
            <i className="fa-solid fa-xmark"></i>
          </button>
          
          {selectedVehicle.images.length > 1 && (
            <>
              <button 
                onClick={handlePrevImage}
                className="absolute left-8 top-1/2 -translate-y-1/2 text-white/30 hover:text-white text-6xl transition-all z-[110] p-4 rounded-full hover:bg-white/5"
              >
                <i className="fa-solid fa-angle-left"></i>
              </button>
              <button 
                onClick={handleNextImage}
                className="absolute right-8 top-1/2 -translate-y-1/2 text-white/30 hover:text-white text-6xl transition-all z-[110] p-4 rounded-full hover:bg-white/5"
              >
                <i className="fa-solid fa-angle-right"></i>
              </button>
            </>
          )}

          <div className={`transition-opacity duration-300 ${imageTransition ? 'opacity-100' : 'opacity-0'}`}>
            <img 
              src={selectedVehicle.images[activeImageIndex]} 
              className="max-w-full max-h-[85vh] object-contain cursor-zoom-out select-none shadow-2xl"
              alt="Zoomed Vehicle"
              onClick={() => setIsZoomed(false)}
            />
          </div>
          
          {selectedVehicle.images.length > 1 && (
            <div className="absolute bottom-8 left-0 right-0 flex justify-center gap-3">
              {selectedVehicle.images.map((_, i) => (
                <button 
                  key={i} 
                  onClick={() => setActiveImageIndex(i)}
                  className={`w-3 h-3 rounded-full transition-all ${i === activeImageIndex ? 'bg-accent scale-125' : 'bg-white/20 hover:bg-white/40'}`} 
                />
              ))}
            </div>
          )}
        </div>
      )}

      {/* Vehicle Details Modal */}
      {selectedVehicle && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 sm:p-6">
          <div 
            className="absolute inset-0 bg-slate-900/60 backdrop-blur-md transition-opacity"
            onClick={closeModal}
          ></div>
          
          <div className="relative bg-white dark:bg-slate-900 w-full max-w-5xl max-h-[90vh] rounded-[2.5rem] overflow-hidden shadow-2xl flex flex-col md:flex-row animate-in fade-in zoom-in-95 duration-300">
            {/* Close Button */}
            <button 
              onClick={closeModal}
              className="absolute top-6 left-6 z-[70] bg-black/10 hover:bg-black/40 backdrop-blur-md text-white p-2 rounded-full transition-all shadow-lg hover:scale-110 flex items-center justify-center w-10 h-10"
            >
              <i className="fa-solid fa-xmark text-xl"></i>
            </button>

            {/* Modal Left: Image Gallery */}
            <div className={`md:w-1/2 bg-slate-100 dark:bg-slate-800 relative transition-all duration-500 overflow-hidden ${modalView !== 'details' ? 'opacity-50 grayscale' : ''}`}>
              <div className="h-64 md:h-full overflow-hidden relative group">
                <div className={`w-full h-full transition-opacity duration-300 ${imageTransition ? 'opacity-100' : 'opacity-0'}`}>
                    <img 
                      src={selectedVehicle.images && selectedVehicle.images.length > 0 ? selectedVehicle.images[activeImageIndex] : PLACEHOLDER_IMAGE} 
                      className={`w-full h-full object-cover ${selectedVehicle.images && selectedVehicle.images.length > 0 ? 'cursor-zoom-in' : ''}`} 
                      alt={selectedVehicle.model} 
                      onClick={() => selectedVehicle.images && selectedVehicle.images.length > 0 && setIsZoomed(true)}
                    />
                </div>
                
                {/* Navigation Arrows (Visible on Hover) */}
                {selectedVehicle.images && selectedVehicle.images.length > 1 && (
                  <>
                    <button 
                      onClick={handlePrevImage}
                      className="absolute left-4 top-1/2 -translate-y-1/2 bg-black/20 hover:bg-black/60 text-white w-12 h-12 rounded-full flex items-center justify-center transition-all opacity-0 group-hover:opacity-100 shadow-xl"
                    >
                      <i className="fa-solid fa-chevron-left"></i>
                    </button>
                    <button 
                      onClick={handleNextImage}
                      className="absolute right-4 top-1/2 -translate-y-1/2 bg-black/20 hover:bg-black/60 text-white w-12 h-12 rounded-full flex items-center justify-center transition-all opacity-0 group-hover:opacity-100 shadow-xl"
                    >
                      <i className="fa-solid fa-chevron-right"></i>
                    </button>
                  </>
                )}

                {selectedVehicle.images && selectedVehicle.images.length > 0 && (
                  <div className="absolute top-6 right-6">
                    <button 
                      onClick={() => setIsZoomed(true)}
                      className="bg-black/20 hover:bg-black/50 backdrop-blur-md text-white p-3 rounded-xl transition-all shadow-lg"
                      title="Zoom In"
                    >
                      <i className="fa-solid fa-maximize"></i>
                    </button>
                  </div>
                )}
              </div>

              {/* Thumbnails */}
              {selectedVehicle.images && selectedVehicle.images.length > 1 && (
                <div className="absolute bottom-6 left-0 right-0 flex justify-center gap-3 px-6 overflow-x-auto pb-2 scrollbar-hide">
                  {selectedVehicle.images.map((img, idx) => (
                    <button 
                      key={idx} 
                      onClick={() => {
                        setImageTransition(false);
                        setTimeout(() => {
                          setActiveImageIndex(idx);
                          setImageTransition(true);
                        }, 50);
                      }}
                      className={`w-16 h-12 rounded-lg border-2 flex-shrink-0 overflow-hidden cursor-pointer transition-all ${activeImageIndex === idx ? 'border-accent scale-110 shadow-xl -translate-y-1' : 'border-white/30 hover:border-white'}`}
                    >
                      <img src={img} className="w-full h-full object-cover" alt={`Thumb ${idx}`} />
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Modal Right: Content */}
            <div className="md:w-1/2 p-8 md:p-12 overflow-y-auto bg-white dark:bg-slate-900 relative custom-scrollbar">
              {modalView === 'details' && (
                <div className="space-y-8 animate-in fade-in slide-in-from-right-4 duration-500">
                  <div className="space-y-2 pt-8 md:pt-0">
                    <div className="flex justify-between items-start">
                      <span className="text-accent font-bold uppercase tracking-widest text-[10px] bg-accent/10 px-2 py-0.5 rounded">{selectedVehicle.year} Model</span>
                      <span className="text-2xl font-bold text-primary dark:text-white">${selectedVehicle.price.toLocaleString()}</span>
                    </div>
                    <h2 className="text-4xl font-serif font-bold leading-tight">{selectedVehicle.make} {selectedVehicle.model}</h2>
                    <div className="flex items-center gap-3">
                       <span className="text-slate-500 text-sm font-medium">{selectedVehicle.trim} &bull; {selectedVehicle.color}</span>
                       <span className="bg-slate-100 dark:bg-slate-800 text-[10px] font-bold uppercase tracking-widest px-2 py-0.5 rounded text-primary dark:text-white">{selectedVehicle.bodyStyle}</span>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="bg-slate-50 dark:bg-slate-800 p-4 rounded-2xl border border-slate-100 dark:border-slate-700">
                      <p className="text-[10px] uppercase font-bold text-slate-400 mb-1 tracking-widest">Mileage</p>
                      <p className="font-bold">{selectedVehicle.km.toLocaleString()} KM</p>
                    </div>
                    <div className="bg-slate-50 dark:bg-slate-800 p-4 rounded-2xl border border-slate-100 dark:border-slate-700">
                      <p className="text-[10px] uppercase font-bold text-slate-400 mb-1 tracking-widest">Fuel Type</p>
                      <p className="font-bold">{selectedVehicle.fuelType}</p>
                    </div>
                  </div>

                  <div className="space-y-6">
                    <h4 className="font-bold border-b border-slate-100 dark:border-slate-800 pb-2 flex items-center gap-2 text-primary dark:text-white text-sm uppercase tracking-wider">
                       <i className="fa-solid fa-list-check text-accent"></i> Key Features
                    </h4>
                    
                    <div className="grid grid-cols-2 gap-y-6 gap-x-8">
                      <div className="space-y-3">
                        <h5 className="text-[10px] font-bold text-slate-400 uppercase flex items-center gap-2 tracking-widest">
                          <i className="fa-solid fa-shield-halved text-xs"></i> Safety
                        </h5>
                        <ul className="text-sm space-y-1">
                          {selectedVehicle.features.safety.map(f => <li key={f} className="flex items-center gap-2 text-slate-600 dark:text-slate-400"><i className="fa-solid fa-circle-check text-accent text-[8px]"></i> {f}</li>)}
                        </ul>
                      </div>
                      <div className="space-y-3">
                        <h5 className="text-[10px] font-bold text-slate-400 uppercase flex items-center gap-2 tracking-widest">
                          <i className="fa-solid fa-laptop text-xs"></i> Infotainment
                        </h5>
                        <ul className="text-sm space-y-1">
                          {selectedVehicle.features.infotainment.map(f => <li key={f} className="flex items-center gap-2 text-slate-600 dark:text-slate-400"><i className="fa-solid fa-circle-check text-accent text-[8px]"></i> {f}</li>)}
                        </ul>
                      </div>
                    </div>
                  </div>

                  <div className="pt-8 flex flex-col sm:flex-row gap-4">
                    <button 
                      onClick={handleBookTestDrive}
                      disabled={isProcessing}
                      className="flex-grow bg-accent text-primary py-4 rounded-2xl font-bold text-lg hover:bg-amber-500 transition-all shadow-xl hover:shadow-accent/30 flex items-center justify-center gap-2 active:scale-95"
                    >
                      {isProcessing ? <i className="fa-solid fa-spinner fa-spin"></i> : <i className="fa-solid fa-calendar-check"></i>}
                      Book Test Drive
                    </button>
                    <button 
                      onClick={handleInquireNow}
                      disabled={isProcessing}
                      className="flex-grow bg-primary text-white py-4 rounded-2xl font-bold text-lg hover:bg-slate-800 transition-all flex items-center justify-center gap-2 active:scale-95 shadow-lg"
                    >
                      {isProcessing ? <i className="fa-solid fa-spinner fa-spin"></i> : <i className="fa-solid fa-paper-plane"></i>}
                      Inquire Now
                    </button>
                  </div>
                </div>
              )}

              {modalView === 'booking-success' && (
                <div className="h-full flex flex-col items-center justify-center text-center space-y-6 animate-in zoom-in-95 duration-500 pt-16">
                  <div className="w-20 h-20 bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600 rounded-full flex items-center justify-center">
                    <i className="fa-solid fa-check text-4xl"></i>
                  </div>
                  <div className="space-y-2">
                    <h3 className="text-3xl font-serif font-bold text-primary dark:text-white">Request Received</h3>
                    <p className="text-slate-500">
                      Our concierge will contact you shortly to confirm your private appointment.
                    </p>
                  </div>
                  <button onClick={() => setModalView('details')} className="text-accent font-bold hover:underline">Back to Details</button>
                </div>
              )}
              
              {modalView === 'auth-required' && (
                <div className="h-full flex flex-col items-center justify-center text-center space-y-6 animate-in fade-in duration-500 pt-16">
                  <div className="w-20 h-20 bg-amber-100 dark:bg-amber-900/30 text-amber-600 rounded-full flex items-center justify-center">
                    <i className="fa-solid fa-lock text-3xl"></i>
                  </div>
                  <div className="space-y-2">
                    <h3 className="text-3xl font-serif font-bold text-primary dark:text-white">Sign In Required</h3>
                    <p className="text-slate-500">To proceed, please sign in to your OldRoad Auto account.</p>
                  </div>
                  <Link to="/auth" className="w-full bg-primary text-white py-4 rounded-xl font-bold shadow-lg hover:bg-slate-800 transition-all text-center" onClick={closeModal}>Go to Login</Link>
                </div>
              )}

              <div className="mt-12 text-center opacity-50">
                <p className="text-[10px] text-slate-400 flex items-center justify-center gap-2 uppercase tracking-widest font-bold">
                  <i className="fa-solid fa-location-dot"></i> {selectedVehicle.location}
                </p>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default InventoryPage;
