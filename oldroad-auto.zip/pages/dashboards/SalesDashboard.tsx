
import React, { useState, useMemo, useRef } from 'react';
import { User, Vehicle, VehicleStatus, TradeRequest } from '../../types';
import { MOCK_VEHICLES, MOCK_TRADE_REQUESTS, PLACEHOLDER_IMAGE } from '../../constants';
import { Link } from 'react-router-dom';
import { generateMarketingCopy, getMarketInsights } from '../../geminiService';

interface DashboardProps {
  user: User;
  darkMode: boolean;
  toggleDarkMode: () => void;
}

interface DispatchArrival {
  id: string;
  year: number;
  make: string;
  model: string;
  trim: string;
  vin: string;
  lotNumber: string;
  status: 'Pending' | 'Paid' | 'Picked Up' | 'Delivered' | 'Fixing' | 'Ready to Sell';
}

const SalesDashboard: React.FC<DashboardProps> = ({ user, darkMode, toggleDarkMode }) => {
  // --- STATE ---
  const [vehicles, setVehicles] = useState<Vehicle[]>(MOCK_VEHICLES);
  const [tradeRequests, setTradeRequests] = useState<TradeRequest[]>(MOCK_TRADE_REQUESTS);
  const [notification, setNotification] = useState<string | null>(null);
  
  // Modals
  const [isSourcingModalOpen, setIsSourcingModalOpen] = useState(false);
  const [sourcingSearch, setSourcingSearch] = useState('');
  const [isVehicleEditorOpen, setIsVehicleEditorOpen] = useState(false);
  const [isDetailsModalOpen, setIsDetailsModalOpen] = useState(false);
  const [isTradeModalOpen, setIsTradeModalOpen] = useState(false);
  const [isContractModalOpen, setIsContractModalOpen] = useState(false);
  const [isInsightModalOpen, setIsInsightModalOpen] = useState(false);
  
  // Data Refs
  const [editingVehicle, setEditingVehicle] = useState<Partial<Vehicle> | null>(null);
  const [selectedVehicle, setSelectedVehicle] = useState<Vehicle | null>(null);
  const [selectedTrade, setSelectedTrade] = useState<TradeRequest | null>(null);
  const [marketInsight, setMarketInsight] = useState<{ text: string; sources: any[] } | null>(null);
  const [isGeneratingAI, setIsGeneratingAI] = useState(false);
  
  // File Upload Ref
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Contract State
  const [buyerName, setBuyerName] = useState('');
  const [salePrice, setSalePrice] = useState<number>(0);
  const [saleDate, setSaleDate] = useState(new Date().toISOString().split('T')[0]);

  // Trade Appraisal Form State
  const [offerValue, setOfferValue] = useState<string>('');
  const [staffNote, setStaffNote] = useState<string>('');
  const [isAppraising, setIsAppraising] = useState(false);
  const [isFinalizingContract, setIsFinalizingContract] = useState(false);

  // --- PERFORMANCE CALCULATIONS ---
  const mySales = useMemo(() => {
    return vehicles.filter(v => v.status === VehicleStatus.SOLD && v.soldById === user.id);
  }, [vehicles, user.id]);

  const totalRevenue = useMemo(() => {
    return mySales.reduce((acc, curr) => acc + curr.price, 0);
  }, [mySales]);

  const activeLeadsCount = useMemo(() => {
    return tradeRequests.filter(tr => tr.status !== 'Completed').length + 12; 
  }, [tradeRequests]);

  const monthlyTarget = 15;
  const targetPercentage = Math.min(Math.round((mySales.length / monthlyTarget) * 100), 100);

  // Mock Dispatch Data
  const [dispatchArrivals] = useState<DispatchArrival[]>([
    { id: 'arr-1', year: 2023, make: 'Ford', model: 'F-150', trim: 'Lariat', vin: '1FTF...', lotNumber: '558291', status: 'Ready to Sell' },
    { id: 'arr-2', year: 2022, make: 'BMW', model: 'X5', trim: 'xDrive40i', vin: '5UXW...', lotNumber: '110293', status: 'Fixing' },
    { id: 'arr-3', year: 2024, make: 'Toyota', model: 'Camry', trim: 'XSE Hybrid', vin: '4T1B...', lotNumber: '992012', status: 'Ready to Sell' }
  ]);

  const showNotification = (msg: string) => {
    setNotification(msg);
    setTimeout(() => setNotification(null), 3000);
  };

  // Filtered Dispatch Arrivals for the sourcing modal
  const filteredArrivals = useMemo(() => {
    return dispatchArrivals.filter(arrival => {
      const searchStr = `${arrival.year} ${arrival.make} ${arrival.model} ${arrival.vin} ${arrival.lotNumber}`.toLowerCase();
      return searchStr.includes(sourcingSearch.toLowerCase());
    });
  }, [dispatchArrivals, sourcingSearch]);

  // --- HANDLERS ---
  const handleOpenSourcingModal = () => {
    setSourcingSearch('');
    setIsSourcingModalOpen(true);
  };

  const handleSelectFromDispatch = (arrival: DispatchArrival) => {
    if (arrival.status !== 'Ready to Sell') return;

    setEditingVehicle({
      id: '',
      vin: arrival.vin,
      year: arrival.year,
      make: arrival.make,
      model: arrival.model,
      trim: arrival.trim,
      price: 0,
      km: 0,
      fuelType: 'Gas',
      bodyStyle: 'SUV', 
      status: VehicleStatus.READY,
      location: user.location || 'Main Showroom',
      images: [],
      description: '',
      features: { exterior: [], interior: [], infotainment: [], safety: [] }
    });
    
    setIsSourcingModalOpen(false);
    setIsVehicleEditorOpen(true);
  };

  const handleGenerateAIListing = async () => {
    if (!editingVehicle) return;
    setIsGeneratingAI(true);
    const result = await generateMarketingCopy(editingVehicle, 'Luxury and Professional');
    if (result) {
      setEditingVehicle(prev => prev ? { 
        ...prev, 
        description: `${result.headline}\n\n${result.description}\n\nHighlights:\n${result.highlights.map((h: string) => `• ${h}`).join('\n')}\n\n${result.cta}` 
      } : null);
    }
    setIsGeneratingAI(false);
    showNotification("AI Marketing Copy generated successfully.");
  };

  const handleFetchInsights = async (e: React.MouseEvent, v: Vehicle) => {
    e.stopPropagation();
    setIsGeneratingAI(true);
    const data = await getMarketInsights(v.make, v.model, v.year);
    setMarketInsight(data);
    setSelectedVehicle(v);
    setIsInsightModalOpen(true);
    setIsGeneratingAI(false);
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || !editingVehicle) return;

    Array.from(files).forEach((file: File) => {
      const reader = new FileReader();
      reader.onload = (ev) => {
        const base64 = ev.target?.result as string;
        setEditingVehicle(prev => {
          if (!prev) return null;
          return {
            ...prev,
            images: [...(prev.images || []), base64]
          };
        });
      };
      reader.readAsDataURL(file);
    });
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const removeUploadImage = (index: number) => {
    setEditingVehicle(prev => {
      if (!prev) return null;
      const updatedImages = [...(prev.images || [])];
      updatedImages.splice(index, 1);
      return { ...prev, images: updatedImages };
    });
  };

  const handleSaveListing = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingVehicle) return;

    const newVehicle = {
      ...editingVehicle,
      id: `v-s-${Math.random().toString(36).substr(2, 9)}`,
      images: editingVehicle.images?.length ? editingVehicle.images : [PLACEHOLDER_IMAGE]
    } as Vehicle;

    setVehicles(prev => [newVehicle, ...prev]);
    setIsVehicleEditorOpen(false);
    setEditingVehicle(null);
    showNotification(`${newVehicle.make} ${newVehicle.model} is now live!`);
  };

  const handleGenerateContract = (e: React.MouseEvent, v: Vehicle) => {
    e.stopPropagation();
    setSelectedVehicle(v);
    setBuyerName('');
    setSalePrice(v.price);
    setSaleDate(new Date().toISOString().split('T')[0]);
    setIsContractModalOpen(true);
  };

  const handleFinalizeSale = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedVehicle) return;

    setIsFinalizingContract(true);
    setTimeout(() => {
      setVehicles(prev => prev.map(v => 
        v.id === selectedVehicle.id 
        ? { 
            ...v, 
            status: VehicleStatus.SOLD, 
            soldById: user.id, 
            saleDate: saleDate,
            buyerName: buyerName,
            price: salePrice
          } 
        : v
      ));
      setIsFinalizingContract(false);
      setIsContractModalOpen(false);
      setSelectedVehicle(null);
      showNotification(`Contract finalized! ${selectedVehicle.make} ${selectedVehicle.model} marked as SOLD.`);
    }, 1500);
  };

  const handleOpenTradeAppraisal = (e: React.MouseEvent, trade: TradeRequest) => {
    e.stopPropagation();
    setSelectedTrade(trade);
    setOfferValue(trade.offerAmount?.toString() || '');
    setStaffNote(trade.staffNotes || '');
    setIsTradeModalOpen(true);
  };

  const handleSendTradeOffer = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedTrade) return;
    
    setIsAppraising(true);
    setTimeout(() => {
      const updatedTrade = {
        ...selectedTrade,
        status: 'Offered' as const,
        offerAmount: parseInt(offerValue),
        staffNotes: staffNote,
        appraisedBy: user.firstName
      };
      
      setTradeRequests(prev => prev.map(t => t.id === selectedTrade.id ? updatedTrade : t));
      setIsAppraising(false);
      setIsTradeModalOpen(false);
      showNotification(`Offer sent to ${selectedTrade.customerName}`);
    }, 1200);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-12 relative">
      {/* Toast Notification */}
      {notification && (
        <div className="fixed top-24 right-8 z-[150] animate-in slide-in-from-right-full duration-300">
          <div className="bg-primary text-white px-6 py-4 rounded-2xl shadow-2xl flex items-center gap-3 border border-slate-700">
            <i className="fa-solid fa-circle-check text-accent"></i>
            <span className="font-bold text-sm">{notification}</span>
          </div>
        </div>
      )}

      {/* Market Insight Modal */}
      {isInsightModalOpen && selectedVehicle && marketInsight && (
        <div className="fixed inset-0 z-[150] flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-slate-900/60 backdrop-blur-md" onClick={() => setIsInsightModalOpen(false)}></div>
          <div className="relative bg-white dark:bg-slate-900 w-full max-w-2xl rounded-[2.5rem] p-8 shadow-2xl animate-in zoom-in-95 duration-200">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-2xl font-serif font-bold">Market Intelligence</h2>
              <button onClick={() => setIsInsightModalOpen(false)} className="w-10 h-10 rounded-full bg-slate-100 dark:bg-slate-800 flex items-center justify-center"><i className="fa-solid fa-xmark"></i></button>
            </div>
            <div className="space-y-6">
               <div className="prose dark:prose-invert max-w-none text-slate-600 dark:text-slate-400">
                  {marketInsight.text.split('\n').map((l, i) => <p key={i}>{l}</p>)}
               </div>
               {marketInsight.sources.length > 0 && (
                 <div className="pt-4 border-t border-slate-100 dark:border-slate-800">
                   <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-3">Grounding Sources</p>
                   <div className="flex flex-wrap gap-2">
                     {marketInsight.sources.map((chunk: any, i: number) => (
                       chunk.web && (
                         <a key={i} href={chunk.web.uri} target="_blank" rel="noopener noreferrer" className="text-xs text-blue-500 hover:underline">
                           {chunk.web.title}
                         </a>
                       )
                     ))}
                   </div>
                 </div>
               )}
            </div>
          </div>
        </div>
      )}

      {/* Contract Generation Modal */}
      {isContractModalOpen && selectedVehicle && (
        <div className="fixed inset-0 z-[140] flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm" onClick={() => setIsContractModalOpen(false)}></div>
          <div className="relative bg-white dark:bg-slate-900 w-full max-w-xl rounded-[2.5rem] p-8 shadow-2xl animate-in zoom-in-95 duration-200">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-2xl font-serif font-bold">Generate Sales Contract</h2>
              <button onClick={() => setIsContractModalOpen(false)} className="w-10 h-10 rounded-full bg-slate-100 dark:bg-slate-800 flex items-center justify-center shadow-sm"><i className="fa-solid fa-xmark"></i></button>
            </div>
            
            <form onSubmit={handleFinalizeSale} className="space-y-6">
              <div className="p-5 bg-emerald-50 dark:bg-emerald-900/20 border border-emerald-100 dark:border-emerald-800 rounded-2xl flex items-center gap-4">
                <div className="w-12 h-12 bg-white dark:bg-slate-900 rounded-xl flex items-center justify-center text-emerald-600 shadow-sm">
                  <i className="fa-solid fa-file-contract text-xl"></i>
                </div>
                <div>
                  <p className="font-bold text-slate-900 dark:text-white">{selectedVehicle.year} {selectedVehicle.make} {selectedVehicle.model}</p>
                  <p className="text-xs text-slate-500 font-mono">VIN: {selectedVehicle.vin}</p>
                </div>
              </div>

              <div className="space-y-4">
                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-slate-400 uppercase">Buyer Full Name</label>
                  <input 
                    type="text" 
                    required 
                    placeholder="John Doe" 
                    className="w-full p-4 bg-slate-50 dark:bg-slate-800 rounded-xl font-bold outline-none focus:ring-2 focus:ring-accent"
                    value={buyerName}
                    onChange={e => setBuyerName(e.target.value)}
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-slate-400 uppercase">Agreed Sale Price</label>
                    <div className="relative">
                       <span className="absolute left-4 top-1/2 -translate-y-1/2 font-bold text-slate-400">$</span>
                       <input 
                        type="number" 
                        required 
                        className="w-full p-4 pl-8 bg-slate-50 dark:bg-slate-800 rounded-xl font-bold outline-none focus:ring-2 focus:ring-accent" 
                        value={salePrice}
                        onChange={e => setSalePrice(parseInt(e.target.value))}
                       />
                    </div>
                  </div>
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-slate-400 uppercase">Sale Date</label>
                    <input 
                        type="date" 
                        required 
                        className="w-full p-4 bg-slate-50 dark:bg-slate-800 rounded-xl font-bold outline-none focus:ring-2 focus:ring-accent" 
                        value={saleDate}
                        onChange={e => setSaleDate(e.target.value)}
                    />
                  </div>
                </div>
              </div>

              <button 
                type="submit" 
                disabled={isFinalizingContract}
                className="w-full py-4 bg-emerald-600 text-white rounded-xl font-bold flex items-center justify-center gap-2 hover:bg-emerald-700 transition-all active:scale-95 shadow-xl shadow-emerald-500/10"
              >
                {isFinalizingContract ? <i className="fa-solid fa-spinner fa-spin"></i> : <i className="fa-solid fa-signature"></i>}
                Finalize Contract & Close Sale
              </button>
            </form>
          </div>
        </div>
      )}

      {/* Sourcing Modal */}
      {isSourcingModalOpen && (
        <div className="fixed inset-0 z-[140] flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm" onClick={() => setIsSourcingModalOpen(false)}></div>
          <div className="relative bg-white dark:bg-slate-900 w-full max-w-xl rounded-[2.5rem] p-8 shadow-2xl border border-slate-200 dark:border-slate-800 animate-in zoom-in-95 duration-200">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-2xl font-serif font-bold">List Ready Asset</h2>
              <button onClick={() => setIsSourcingModalOpen(false)} className="w-10 h-10 rounded-full bg-slate-100 dark:bg-slate-800 flex items-center justify-center"><i className="fa-solid fa-xmark"></i></button>
            </div>

            <div className="mb-6 relative">
              <i className="fa-solid fa-magnifying-glass absolute left-4 top-1/2 -translate-y-1/2 text-slate-400"></i>
              <input 
                type="text" 
                placeholder="Search VIN, Lot#, or Make/Model..." 
                className="w-full pl-12 pr-4 py-3 bg-slate-50 dark:bg-slate-800 rounded-xl outline-none focus:ring-2 focus:ring-accent border border-slate-100 dark:border-slate-700 transition-all"
                value={sourcingSearch}
                onChange={(e) => setSourcingSearch(e.target.value)}
              />
            </div>

            <div className="space-y-4 max-h-[50vh] overflow-y-auto pr-2 custom-scrollbar">
              {filteredArrivals.map(arrival => {
                const isReady = arrival.status === 'Ready to Sell';
                return (
                  <div 
                    key={arrival.id} 
                    onClick={() => isReady && handleSelectFromDispatch(arrival)}
                    className={`p-5 rounded-2xl border-2 transition-all flex items-center justify-between ${
                      isReady ? 'border-slate-100 dark:border-slate-800 hover:border-accent cursor-pointer bg-white dark:bg-slate-900 shadow-sm' 
                      : 'opacity-50 grayscale border-slate-50 cursor-not-allowed'
                    }`}
                  >
                    <div className="flex items-center gap-4">
                      <div className={`w-12 h-12 rounded-xl flex items-center justify-center text-xl ${isReady ? 'bg-emerald-50 text-emerald-600' : 'bg-slate-100 text-slate-400'}`}>
                        <i className="fa-solid fa-car-side"></i>
                      </div>
                      <div>
                        <p className="font-bold">{arrival.year} {arrival.make} {arrival.model}</p>
                        <p className="text-[10px] font-mono text-slate-500">VIN: {arrival.vin} • LOT: {arrival.lotNumber}</p>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* HEADER */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6 mb-12">
        <div>
          <div className="flex items-center gap-3 mb-1">
            <span className="bg-accent/10 text-accent text-[10px] font-bold uppercase tracking-widest px-2 py-0.5 rounded">Sales Representative</span>
            <span className="text-slate-400 text-[10px]">&bull;</span>
            <span className="text-slate-400 text-xs font-medium flex items-center gap-1">
              <i className="fa-solid fa-location-dot"></i> {user.location}
            </span>
          </div>
          <h1 className="text-4xl font-serif font-bold">Sales Console</h1>
        </div>
        <div className="flex flex-wrap gap-4">
          <button onClick={handleOpenSourcingModal} className="bg-primary text-white px-8 py-4 rounded-2xl font-bold shadow-xl hover:bg-slate-800 transition-all active:scale-95 flex items-center gap-2">
            <i className="fa-solid fa-plus-circle"></i> List Ready Asset
          </button>
          <button onClick={toggleDarkMode} className="p-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl hover:text-accent transition-colors shadow-sm">
            <i className={`fa-solid ${darkMode ? 'fa-sun' : 'fa-moon'}`}></i>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        {/* SIDEBAR STATS */}
        <div className="lg:col-span-1 space-y-6">
          <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 shadow-sm">
            <h3 className="font-bold mb-4 flex items-center gap-2 text-primary dark:text-white uppercase text-[10px] tracking-[0.2em]"><i className="fa-solid fa-chart-line text-accent"></i> My Performance</h3>
            <div className="space-y-6">
              <div className="flex justify-between items-end">
                <div className="space-y-1">
                  <span className="text-slate-400 text-[10px] font-bold uppercase tracking-wider">Sold this month</span>
                  <p className="font-bold text-3xl text-slate-900 dark:text-white leading-none">{mySales.length}</p>
                </div>
              </div>
              <div className="space-y-1 border-t border-slate-50 dark:border-slate-800 pt-4">
                <span className="text-slate-400 text-[10px] font-bold uppercase tracking-wider">Revenue Generated</span>
                <p className="font-bold text-2xl text-emerald-600 leading-none">${totalRevenue.toLocaleString()}</p>
              </div>
            </div>
          </div>
        </div>

        {/* MAIN FEED */}
        <div className="lg:col-span-3 space-y-8">
          {/* Inventory arrivals */}
          <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 overflow-hidden shadow-sm">
            <div className="p-6 border-b border-slate-100 dark:border-slate-800 flex justify-between items-center bg-slate-50/50 dark:bg-slate-800/20">
              <h3 className="font-bold">Recent Inventory Arrivals</h3>
              <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">Active Inventory</p>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 p-6">
              {vehicles.filter(v => v.status === VehicleStatus.READY).slice(0, 4).map(v => (
                <div key={v.id} onClick={() => { setSelectedVehicle(v); setIsDetailsModalOpen(true); }} className="flex gap-4 p-4 rounded-xl border border-slate-100 dark:border-slate-800 hover:border-accent transition-all bg-slate-50/30 dark:bg-slate-800/30 group cursor-pointer">
                  <div className="w-24 h-24 rounded-lg overflow-hidden flex-shrink-0 bg-slate-100">
                    <img src={v.images[0] || PLACEHOLDER_IMAGE} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" alt="" />
                  </div>
                  <div className="flex-grow">
                    <p className="font-bold text-sm leading-tight">{v.year} {v.make} {v.model}</p>
                    <p className="text-xs text-slate-500 mb-2">${v.price.toLocaleString()} • {v.km.toLocaleString()} KM</p>
                    <div className="flex flex-wrap gap-x-3 gap-y-1">
                      <button 
                        onClick={(e) => handleFetchInsights(e, v)}
                        className="text-[10px] font-bold text-blue-500 uppercase hover:underline"
                      >
                        Market Insights
                      </button>
                      <button 
                        onClick={(e) => handleGenerateContract(e, v)}
                        className="text-[10px] font-bold text-emerald-600 uppercase hover:underline"
                      >
                        Generate Contract
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Pending Trades */}
          <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 overflow-hidden shadow-sm">
            <div className="p-6 border-b border-slate-100 dark:border-slate-800 flex justify-between items-center bg-slate-50/50 dark:bg-slate-800/20">
              <h3 className="font-bold">Pending Trade Requests</h3>
              <Link to="/manage-trades" className="text-accent text-sm font-bold hover:underline">View All →</Link>
            </div>
            <div className="divide-y divide-slate-100 dark:divide-slate-800">
              {tradeRequests.map((trade) => (
                <div key={trade.id} onClick={(e) => handleOpenTradeAppraisal(e, trade)} className="p-6 flex items-center justify-between hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors group cursor-pointer">
                  <div className="flex gap-4 items-center">
                    <div className="w-10 h-10 rounded-full bg-slate-100 dark:bg-slate-800 flex items-center justify-center font-bold text-slate-600 dark:text-slate-300 shadow-sm">
                      {trade.customerName[0]}
                    </div>
                    <div>
                      <p className="font-bold">{trade.customerName}</p>
                      <p className="text-sm text-slate-500">{trade.year} {trade.make} {trade.model}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-6">
                    <span className={`text-[10px] font-bold uppercase tracking-wider px-3 py-1 rounded-full ${trade.status === 'Pending' ? 'bg-amber-100 text-amber-700' : 'bg-emerald-100 text-emerald-700'}`}>
                      {trade.status}
                    </span>
                    <button className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 px-4 py-2 rounded-xl text-xs font-bold text-slate-600 dark:text-slate-300 hover:border-accent hover:text-accent transition-all shadow-sm">
                      Review
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SalesDashboard;
