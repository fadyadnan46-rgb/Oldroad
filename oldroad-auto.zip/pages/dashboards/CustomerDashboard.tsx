
import React, { useState } from 'react';
import { User } from '../../types';
import { Link } from 'react-router-dom';

interface DashboardProps {
  user: User;
  darkMode: boolean;
  toggleDarkMode: () => void;
}

interface SavedSearch {
  id: string;
  name: string;
  criteria: string;
  frequency: 'Instant' | 'Daily' | 'Weekly';
}

interface UserTradeRequest {
  id: string;
  vehicle: string;
  date: string;
  status: 'Pending Review' | 'Appraising' | 'Offer Made';
  offerAmount?: number;
}

const CustomerDashboard: React.FC<DashboardProps> = ({ user, darkMode, toggleDarkMode }) => {
  const [isAlertsModalOpen, setIsAlertsModalOpen] = useState(false);
  const [savedSearches, setSavedSearches] = useState<SavedSearch[]>([
    { id: '1', name: 'Electric SUVs', criteria: 'Ontario • Under 50k KM • EV', frequency: 'Daily' },
    { id: '2', name: 'Luxury Trucks', criteria: 'Toronto • 2022+ • Under $80k', frequency: 'Instant' }
  ]);

  const [tradeRequests] = useState<UserTradeRequest[]>([
    { id: 'TR-8821', vehicle: '2021 Honda Civic Sport', date: 'Today', status: 'Pending Review' },
    { id: 'TR-7712', vehicle: '2018 BMW X5', date: '3 days ago', status: 'Offer Made', offerAmount: 32500 }
  ]);

  const deleteSearch = (id: string) => {
    setSavedSearches(prev => prev.filter(s => s.id !== id));
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-12">
      <div className="flex justify-between items-center mb-12">
        <div>
          <h1 className="text-4xl font-serif font-bold">Hello, {user.firstName}!</h1>
          <p className="text-slate-500">Welcome to your OldRoad Auto command center.</p>
        </div>
        <div className="flex items-center gap-4">
          <button 
            onClick={toggleDarkMode}
            className="p-3 bg-slate-100 dark:bg-slate-800 rounded-xl hover:text-accent transition-colors"
            aria-label="Toggle Dark Mode"
          >
            <i className={`fa-solid ${darkMode ? 'fa-sun' : 'fa-moon'} text-xl`}></i>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <div className="col-span-1 md:col-span-2 space-y-8">
          {/* Stats Bar */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm hover:shadow-md transition-shadow">
              <i className="fa-solid fa-heart text-accent text-3xl mb-4"></i>
              <h3 className="font-bold text-2xl">{savedSearches.length + 2}</h3>
              <p className="text-slate-500">Saved Vehicles</p>
            </div>
            <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm hover:shadow-md transition-shadow">
              <i className="fa-solid fa-clock-rotate-left text-blue-500 text-3xl mb-4"></i>
              <h3 className="font-bold text-2xl">{tradeRequests.length}</h3>
              <p className="text-slate-500">Active Trade Requests</p>
            </div>
          </div>

          {/* Trade Requests Section */}
          <div className="bg-white dark:bg-slate-900 p-8 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm">
            <div className="flex justify-between items-center mb-6">
              <h3 className="text-xl font-bold">My Trade-In Requests</h3>
              <Link to="/trade-in" className="text-accent text-sm font-bold hover:underline">New Request +</Link>
            </div>
            
            <div className="space-y-4">
              {tradeRequests.map(request => (
                <div key={request.id} className="p-5 rounded-2xl border border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/30 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                  <div className="flex gap-4 items-center">
                    <div className="w-12 h-12 bg-white dark:bg-slate-900 rounded-xl flex items-center justify-center text-primary dark:text-white shadow-sm">
                      <i className="fa-solid fa-car-side"></i>
                    </div>
                    <div>
                      <p className="font-bold">{request.vehicle}</p>
                      <p className="text-xs text-slate-400">ID: {request.id} &bull; {request.date}</p>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-4 w-full sm:w-auto justify-between sm:justify-end">
                    <span className={`text-[10px] font-bold uppercase tracking-widest px-3 py-1 rounded-full ${
                      request.status === 'Offer Made' ? 'bg-emerald-100 text-emerald-700' : 
                      request.status === 'Appraising' ? 'bg-amber-100 text-amber-700' : 'bg-slate-200 text-slate-600 dark:bg-slate-700 dark:text-slate-300'
                    }`}>
                      {request.status}
                    </span>
                    
                    {request.status === 'Offer Made' ? (
                      <button className="bg-accent text-primary px-4 py-2 rounded-lg font-bold text-xs hover:bg-amber-500 transition-colors">
                        View Offer (${request.offerAmount?.toLocaleString()})
                      </button>
                    ) : (
                      <button className="text-slate-400 hover:text-primary transition-colors text-sm font-medium">
                        Details
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Recent Activity */}
          <div className="bg-white dark:bg-slate-900 p-8 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm">
            <h3 className="text-xl font-bold mb-6">Recent Activity</h3>
            <div className="space-y-6">
              {[1, 2].map(i => (
                <div key={i} className="flex gap-4 items-center">
                  <div className="w-12 h-12 rounded-xl bg-slate-50 dark:bg-slate-800 flex items-center justify-center">
                    <i className="fa-solid fa-eye text-slate-400"></i>
                  </div>
                  <div className="flex-grow">
                    <p className="font-medium">Viewed <span className="text-accent">2023 GMC Yukon Denali</span></p>
                    <p className="text-xs text-slate-500">2 days ago</p>
                  </div>
                  <button className="text-sm text-slate-400 hover:text-primary transition-colors">View Car</button>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Sidebar */}
        <div className="space-y-8">
          <div className="bg-primary text-white p-8 rounded-2xl relative overflow-hidden group shadow-xl">
            <div className="relative z-10">
              <h3 className="text-xl font-bold mb-2">Trade Your Ride?</h3>
              <p className="text-slate-400 text-sm mb-6 leading-relaxed">Get a professional valuation in seconds using our AI tool and get a firm purchase offer.</p>
              <Link to="/trade-in" className="block w-full text-center bg-accent text-primary py-3 rounded-xl font-bold hover:bg-amber-500 transition-all shadow-lg hover:shadow-accent/20">
                Start Appraisal
              </Link>
            </div>
            <i className="fa-solid fa-car absolute -bottom-10 -right-10 text-9xl text-white/5 rotate-12 group-hover:rotate-0 transition-transform duration-700"></i>
          </div>

          <div className="bg-white dark:bg-slate-900 p-8 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm">
            <h3 className="text-xl font-bold mb-4">Saved Searches</h3>
            <div className="space-y-3">
              {savedSearches.length > 0 ? (
                savedSearches.slice(0, 1).map(search => (
                  <div key={search.id} className="bg-slate-50 dark:bg-slate-800 p-4 rounded-xl border border-slate-200 dark:border-slate-700">
                    <p className="font-bold">{search.name}</p>
                    <p className="text-xs text-slate-500">{search.criteria}</p>
                    <button 
                      onClick={() => setIsAlertsModalOpen(true)}
                      className="mt-4 text-accent text-sm font-bold hover:underline inline-flex items-center gap-1"
                    >
                      Manage Alerts <i className="fa-solid fa-arrow-right text-[10px]"></i>
                    </button>
                  </div>
                ))
              ) : (
                <p className="text-sm text-slate-500 italic">No saved searches yet.</p>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Manage Alerts Modal */}
      {isAlertsModalOpen && (
        <div className="fixed inset-0 z-[70] flex items-center justify-center p-4">
          <div 
            className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm transition-opacity"
            onClick={() => setIsAlertsModalOpen(false)}
          ></div>
          
          <div className="relative bg-white dark:bg-slate-900 w-full max-w-lg rounded-3xl overflow-hidden shadow-2xl animate-in fade-in zoom-in-95 duration-200 border border-slate-200 dark:border-slate-800">
            <div className="p-6 border-b border-slate-100 dark:border-slate-800 flex justify-between items-center bg-slate-50/50 dark:bg-slate-800/50">
              <h3 className="text-xl font-bold flex items-center gap-2">
                <i className="fa-solid fa-bell text-accent"></i> My Saved Alerts
              </h3>
              <button 
                onClick={() => setIsAlertsModalOpen(false)}
                className="text-slate-400 hover:text-primary transition-colors p-2 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800"
              >
                <i className="fa-solid fa-xmark"></i>
              </button>
            </div>
            
            <div className="p-6 max-h-[60vh] overflow-y-auto">
              {savedSearches.length > 0 ? (
                <div className="space-y-4">
                  {savedSearches.map(search => (
                    <div 
                      key={search.id} 
                      className="p-4 rounded-2xl border border-slate-100 dark:border-slate-800 bg-white dark:bg-slate-900 hover:shadow-md transition-shadow flex items-center justify-between group"
                    >
                      <div className="space-y-1">
                        <p className="font-bold text-lg">{search.name}</p>
                        <p className="text-xs text-slate-500">{search.criteria}</p>
                        <div className="flex gap-2 mt-2">
                          <span className="text-[10px] font-bold uppercase tracking-widest bg-slate-100 dark:bg-slate-800 px-2 py-0.5 rounded text-slate-400">
                            {search.frequency}
                          </span>
                        </div>
                      </div>
                      <button 
                        onClick={() => deleteSearch(search.id)}
                        className="p-3 text-slate-300 hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-xl transition-all opacity-0 group-hover:opacity-100"
                        title="Delete Alert"
                      >
                        <i className="fa-solid fa-trash-can"></i>
                      </button>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-12">
                  <i className="fa-solid fa-bell-slash text-4xl text-slate-200 mb-4 block"></i>
                  <p className="text-slate-500 font-medium">You don't have any active alerts.</p>
                  <button 
                    onClick={() => setIsAlertsModalOpen(false)}
                    className="mt-6 text-accent font-bold text-sm hover:underline"
                  >
                    Browse inventory to save a search
                  </button>
                </div>
              )}
            </div>

            <div className="p-6 bg-slate-50 dark:bg-slate-800/50 border-t border-slate-100 dark:border-slate-800 flex justify-end">
              <button 
                onClick={() => setIsAlertsModalOpen(false)}
                className="bg-primary text-white px-8 py-3 rounded-xl font-bold hover:bg-slate-800 transition-all shadow-lg"
              >
                Done
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default CustomerDashboard;
