
import React, { useState, useMemo, useRef } from 'react';
import { User, Vehicle, VehicleStatus, Location } from '../../types';
import { MOCK_VEHICLES, PLACEHOLDER_IMAGE } from '../../constants';
import { Link } from 'react-router-dom';

interface DashboardProps {
  user: User;
  darkMode: boolean;
  toggleDarkMode: () => void;
  locations: Location[];
  setLocations: React.Dispatch<React.SetStateAction<Location[]>>;
}

type ActivityType = 'SALE' | 'LISTING' | 'APPRAISAL' | 'SYSTEM';

interface InventoryLog {
  id: string;
  type: ActivityType;
  car: string;
  vin: string;
  status: 'Completed' | 'Pending' | 'Flagged';
  loc: string;
  val: string;
  timestamp: string;
  user: string;
  vehicleId?: string;
}

interface DispatchArrival {
  id: string;
  year: number;
  make: string;
  model: string;
  trim: string;
  vin: string;
  lotNumber: string;
  status: 'Pending' | 'Paid' | 'Picked Up' | 'Delivered' | 'Fixing' | 'Ready to Sell';
}

interface SystemConfig {
  markupPercentage: number;
  lowStockThreshold: number;
  showroomCapacity: number;
  maintenanceMode: boolean;
  autoAppraisalEnabled: boolean;
  currency: 'CAD' | 'USD';
}

type ManagementToolType = 'locations' | 'inventory' | null;

const AdminDashboard: React.FC<DashboardProps> = ({ user, darkMode, toggleDarkMode, locations, setLocations }) => {
  // --- STATE ---
  const [vehicles, setVehicles] = useState<Vehicle[]>(MOCK_VEHICLES);
  const [dispatchArrivals] = useState<DispatchArrival[]>([
    { id: 'arr-1', year: 2023, make: 'Ford', model: 'F-150', trim: 'Lariat', vin: '1FTF...', lotNumber: '558291', status: 'Ready to Sell' },
    { id: 'arr-2', year: 2022, make: 'BMW', model: 'X5', trim: 'xDrive40i', vin: '5UXW...', lotNumber: '110293', status: 'Fixing' },
    { id: 'arr-3', year: 2024, make: 'Toyota', model: 'Camry', trim: 'XSE Hybrid', vin: '4T1B...', lotNumber: '992012', status: 'Ready to Sell' },
    { id: 'arr-4', year: 2021, make: 'Honda', model: 'Civic', trim: 'Sport', vin: '1HGC...', lotNumber: '228391', status: 'Delivered' }
  ]);

  const [logs, setLogs] = useState<InventoryLog[]>([
    { id: 'LOG-101', type: 'SALE', car: 'GMC Yukon Denali', vin: '1GKS...', status: 'Completed', loc: 'Showroom', val: '$92,000', timestamp: '10m ago', user: 'j.seller', vehicleId: 'v1' },
    { id: 'LOG-102', type: 'LISTING', car: 'Tesla Model 3', vin: '5YJ3...', status: 'Pending', loc: 'Warehouse', val: '$48,000', timestamp: '45m ago', user: 'm.admin', vehicleId: 'v3' },
    { id: 'LOG-103', type: 'APPRAISAL', car: 'Toyota RAV4', vin: '2T3P...', status: 'Completed', loc: 'Showroom', val: '$45,000', timestamp: '2h ago', user: 'm.admin', vehicleId: 'v2' }
  ]);

  const [activeTool, setActiveTool] = useState<ManagementToolType>(null);
  const [notification, setNotification] = useState<string | null>(null);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isSourcingModalOpen, setIsSourcingModalOpen] = useState(false);
  const [sourcingSearch, setSourcingSearch] = useState('');
  const [isVehicleEditorOpen, setIsVehicleEditorOpen] = useState(false);
  const [editingVehicle, setEditingVehicle] = useState<Partial<Vehicle> | null>(null);
  
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [locationToDelete, setLocationToDelete] = useState<Location | null>(null);

  const [isAddingLocation, setIsAddingLocation] = useState(false);
  const [newLocation, setNewLocation] = useState<Partial<Location>>({
    name: '', address: '', type: 'Showroom', phone: '', email: ''
  });

  const [systemConfig, setSystemConfig] = useState<SystemConfig>({
    markupPercentage: 15,
    lowStockThreshold: 5,
    showroomCapacity: 25,
    maintenanceMode: false,
    autoAppraisalEnabled: true,
    currency: 'CAD'
  });

  const showNotification = (msg: string) => {
    setNotification(msg);
    setTimeout(() => setNotification(null), 3000);
  };

  const dashboardLogs = useMemo(() => logs.slice(0, 10), [logs]);
  const filteredArrivals = useMemo(() => {
    return dispatchArrivals.filter(arrival => {
      const searchStr = `${arrival.year} ${arrival.make} ${arrival.model} ${arrival.vin} ${arrival.lotNumber}`.toLowerCase();
      return searchStr.includes(sourcingSearch.toLowerCase());
    });
  }, [dispatchArrivals, sourcingSearch]);

  const handleOpenSourcingModal = () => {
    setSourcingSearch('');
    setIsSourcingModalOpen(true);
  };

  const handleSelectFromDispatch = (arrival: DispatchArrival) => {
    if (arrival.status !== 'Ready to Sell') return;
    setEditingVehicle({
      id: '', vin: arrival.vin, year: arrival.year, make: arrival.make, model: arrival.model,
      trim: arrival.trim, price: 0, km: 0, fuelType: 'Gas', bodyStyle: 'SUV', status: VehicleStatus.READY,
      location: 'Main Showroom', images: [], features: { exterior: [], interior: [], infotainment: [], safety: [] }
    });
    setIsSourcingModalOpen(false);
    setIsVehicleEditorOpen(true);
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || !editingVehicle) return;
    Array.from(files).forEach((file: File) => {
      const reader = new FileReader();
      reader.onload = (ev) => {
        const base64 = ev.target?.result as string;
        setEditingVehicle(prev => prev ? { ...prev, images: [...(prev.images || []), base64] } : null);
      };
      reader.readAsDataURL(file);
    });
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const removeUploadImage = (index: number) => {
    setEditingVehicle(prev => {
      if (!prev) return null;
      const updatedImages = [...(prev.images || [])];
      updatedImages.splice(index, 1);
      return { ...prev, images: updatedImages };
    });
  };

  const handleSaveVehicle = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingVehicle) return;
    const isNew = !editingVehicle.id;
    const finalVehicle = {
      ...editingVehicle,
      id: isNew ? `v-${Math.random().toString(36).substr(2, 9)}` : editingVehicle.id,
      images: editingVehicle.images?.length ? editingVehicle.images : [PLACEHOLDER_IMAGE],
      features: editingVehicle.features || { exterior: [], interior: [], infotainment: [], safety: [] }
    } as Vehicle;

    if (isNew) {
      setVehicles(prev => [finalVehicle, ...prev]);
      setLogs(prev => [{
        id: `LOG-${Math.floor(Math.random() * 900) + 100}`, type: 'LISTING', car: `${finalVehicle.year} ${finalVehicle.make} ${finalVehicle.model}`,
        vin: finalVehicle.vin.slice(0, 7) + '...', status: 'Completed', loc: finalVehicle.location,
        val: `$${finalVehicle.price.toLocaleString()}`, timestamp: 'Just now', user: 'm.admin', vehicleId: finalVehicle.id
      }, ...prev]);
    } else {
      setVehicles(prev => prev.map(v => v.id === finalVehicle.id ? finalVehicle : v));
    }
    setIsVehicleEditorOpen(false);
    setEditingVehicle(null);
    showNotification(isNew ? 'New vehicle listed successfully' : 'Vehicle details updated');
  };

  const handleSaveSettings = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSettingsOpen(false);
    showNotification('System settings updated successfully');
  };

  const handleRemoveLocationRequest = (e: React.MouseEvent, loc: Location) => {
    e.stopPropagation();
    setLocationToDelete(loc);
  };

  const confirmRemoveLocation = () => {
    if (!locationToDelete) return;
    const locName = locationToDelete.name;
    setLocations(prev => prev.filter(l => l.id !== locationToDelete.id));
    setLocationToDelete(null);
    showNotification(`Location "${locName}" removed from registry`);
  };

  const handleAddLocationSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const loc = { ...newLocation, id: `loc-${Math.random().toString(36).substr(2, 9)}` } as Location;
    setLocations(prev => [...prev, loc]);
    setIsAddingLocation(false);
    setNewLocation({ name: '', address: '', type: 'Showroom', phone: '', email: '' });
    showNotification(`Location "${loc.name}" added successfully. Accountant branch created.`);
  };

  const getActivityIcon = (type: ActivityType) => {
    switch (type) {
      case 'SALE': return <i className="fa-solid fa-hand-holding-dollar text-emerald-500"></i>;
      case 'LISTING': return <i className="fa-solid fa-car-on text-blue-500"></i>;
      case 'APPRAISAL': return <i className="fa-solid fa-magnifying-glass-chart text-accent"></i>;
      case 'SYSTEM': return <i className="fa-solid fa-microchip text-slate-400"></i>;
      default: return <i className="fa-solid fa-circle-info"></i>;
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-12 space-y-12 relative">
      {notification && (
        <div className="fixed top-24 right-8 z-[150] animate-in slide-in-from-right-full duration-300">
          <div className="bg-primary text-white px-6 py-4 rounded-2xl shadow-2xl flex items-center gap-3 border border-slate-700">
            <i className="fa-solid fa-circle-check text-accent"></i>
            <span className="font-bold text-sm">{notification}</span>
          </div>
        </div>
      )}

      {/* --- MODALS --- */}

      {/* Location Deletion Confirm */}
      {locationToDelete && (
        <div className="fixed inset-0 z-[200] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-white dark:bg-slate-900 w-full max-w-md rounded-[2.5rem] p-10 shadow-2xl border border-slate-100 dark:border-slate-800 animate-in zoom-in-95 duration-200">
            <div className="w-16 h-16 bg-rose-50 dark:bg-rose-900/20 text-rose-500 rounded-2xl flex items-center justify-center text-2xl mb-6 mx-auto">
              <i className="fa-solid fa-triangle-exclamation"></i>
            </div>
            <div className="text-center space-y-4 mb-8">
              <h3 className="text-2xl font-serif font-bold text-slate-900 dark:text-white">Delete Location?</h3>
              <p className="text-slate-500 dark:text-slate-400 leading-relaxed font-medium">
                Are you sure you want to remove <span className="text-rose-500 font-bold">{locationToDelete.name}</span>? 
                This will unassign all vehicles currently associated with this site.
              </p>
            </div>
            <div className="flex gap-3">
              <button 
                onClick={() => setLocationToDelete(null)}
                className="flex-1 py-4 bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 rounded-2xl font-bold hover:bg-slate-200 transition-all active:scale-95"
              >
                Cancel
              </button>
              <button 
                onClick={confirmRemoveLocation}
                className="flex-1 py-4 bg-rose-500 text-white rounded-2xl font-bold hover:bg-rose-600 transition-all shadow-xl shadow-rose-500/20 active:scale-95"
              >
                Remove Site
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Add Location Modal */}
      {isAddingLocation && (
        <div className="fixed inset-0 z-[200] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-white dark:bg-slate-900 w-full max-w-lg rounded-[2.5rem] p-10 shadow-2xl border border-slate-100 dark:border-slate-800 animate-in zoom-in-95 duration-200">
            <div className="flex justify-between items-center mb-8">
              <h3 className="text-3xl font-serif font-bold text-slate-900 dark:text-white">New Business Site</h3>
              <button onClick={() => setIsAddingLocation(false)} className="w-10 h-10 rounded-full bg-slate-50 dark:bg-slate-800 flex items-center justify-center text-slate-400 hover:text-slate-900 transition-all"><i className="fa-solid fa-xmark"></i></button>
            </div>
            <form onSubmit={handleAddLocationSubmit} className="space-y-6">
              <div className="space-y-2">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Location Name</label>
                <input required type="text" className="w-full p-4 bg-slate-50 dark:bg-slate-800 rounded-2xl border border-slate-100 dark:border-slate-700 outline-none focus:ring-2 focus:ring-accent font-bold" placeholder="e.g. West Coast Showroom" value={newLocation.name} onChange={e => setNewLocation({...newLocation, name: e.target.value})} />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Site Type</label>
                  <select className="w-full p-4 bg-slate-50 dark:bg-slate-800 rounded-2xl border border-slate-100 dark:border-slate-700 outline-none font-bold" value={newLocation.type} onChange={e => setNewLocation({...newLocation, type: e.target.value as 'Showroom' | 'Warehouse'})}>
                    <option value="Showroom">Showroom</option>
                    <option value="Warehouse">Warehouse</option>
                  </select>
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Phone</label>
                  <input required type="text" className="w-full p-4 bg-slate-50 dark:bg-slate-800 rounded-2xl border border-slate-100 dark:border-slate-700 outline-none" placeholder="555-0100" value={newLocation.phone} onChange={e => setNewLocation({...newLocation, phone: e.target.value})} />
                </div>
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Full Address</label>
                <input required type="text" className="w-full p-4 bg-slate-50 dark:bg-slate-800 rounded-2xl border border-slate-100 dark:border-slate-700 outline-none" placeholder="123 Street Ave, City, ST" value={newLocation.address} onChange={e => setNewLocation({...newLocation, address: e.target.value})} />
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Official Email</label>
                <input required type="email" className="w-full p-4 bg-slate-50 dark:bg-slate-800 rounded-2xl border border-slate-100 dark:border-slate-700 outline-none" placeholder="office@oldroad.auto" value={newLocation.email} onChange={e => setNewLocation({...newLocation, email: e.target.value})} />
              </div>
              <button type="submit" className="w-full py-5 bg-primary text-white rounded-[1.5rem] font-bold shadow-xl shadow-primary/10 hover:bg-slate-800 transition-all active:scale-95">Register Location</button>
            </form>
          </div>
        </div>
      )}

      {/* Settings Modal */}
      {isSettingsOpen && (
        <div className="fixed inset-0 z-[200] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-200">
           <div className="bg-white dark:bg-slate-900 w-full max-w-xl rounded-[2.5rem] p-10 shadow-2xl border border-slate-100 dark:border-slate-800 animate-in zoom-in-95 duration-200">
              <div className="flex justify-between items-center mb-10">
                 <h3 className="text-3xl font-serif font-bold">System Configuration</h3>
                 <button onClick={() => setIsSettingsOpen(false)} className="w-10 h-10 rounded-full bg-slate-50 dark:bg-slate-800 flex items-center justify-center text-slate-400"><i className="fa-solid fa-xmark"></i></button>
              </div>
              <form onSubmit={handleSaveSettings} className="space-y-8">
                 <div className="grid grid-cols-2 gap-6">
                    <div className="space-y-2">
                       <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Global Markup (%)</label>
                       <input type="number" className="w-full p-4 bg-slate-50 dark:bg-slate-800 rounded-2xl border border-slate-100 dark:border-slate-700 outline-none font-bold" value={systemConfig.markupPercentage} onChange={e => setSystemConfig({...systemConfig, markupPercentage: parseInt(e.target.value)})} />
                    </div>
                    <div className="space-y-2">
                       <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Low Stock Alert</label>
                       <input type="number" className="w-full p-4 bg-slate-50 dark:bg-slate-800 rounded-2xl border border-slate-100 dark:border-slate-700 outline-none font-bold" value={systemConfig.lowStockThreshold} onChange={e => setSystemConfig({...systemConfig, lowStockThreshold: parseInt(e.target.value)})} />
                    </div>
                 </div>
                 <div className="flex items-center justify-between p-5 bg-slate-50 dark:bg-slate-800 rounded-3xl">
                    <div>
                       <p className="font-bold text-sm">Automated Appraisal Engine</p>
                       <p className="text-xs text-slate-400">Uses AI to generate baseline trade offers.</p>
                    </div>
                    <button type="button" onClick={() => setSystemConfig({...systemConfig, autoAppraisalEnabled: !systemConfig.autoAppraisalEnabled})} className={`w-14 h-8 rounded-full relative transition-all ${systemConfig.autoAppraisalEnabled ? 'bg-accent' : 'bg-slate-300'}`}>
                       <div className={`absolute top-1 w-6 h-6 bg-white rounded-full transition-all ${systemConfig.autoAppraisalEnabled ? 'left-7' : 'left-1'}`}></div>
                    </button>
                 </div>
                 <div className="flex items-center justify-between p-5 bg-rose-50 dark:bg-rose-900/10 rounded-3xl border border-rose-100 dark:border-rose-900/20">
                    <div>
                       <p className="font-bold text-sm text-rose-900 dark:text-rose-400">Maintenance Mode</p>
                       <p className="text-xs text-rose-800/60 dark:text-rose-400/60">Take public inventory offline for maintenance.</p>
                    </div>
                    <button type="button" onClick={() => setSystemConfig({...systemConfig, maintenanceMode: !systemConfig.maintenanceMode})} className={`w-14 h-8 rounded-full relative transition-all ${systemConfig.maintenanceMode ? 'bg-rose-600' : 'bg-slate-300'}`}>
                       <div className={`absolute top-1 w-6 h-6 bg-white rounded-full transition-all ${systemConfig.maintenanceMode ? 'left-7' : 'left-1'}`}></div>
                    </button>
                 </div>
                 <button type="submit" className="w-full py-5 bg-primary text-white rounded-[1.5rem] font-bold shadow-xl shadow-primary/10 hover:bg-slate-800 transition-all active:scale-95">Commit Global Changes</button>
              </form>
           </div>
        </div>
      )}

      {/* --- DASHBOARD VIEWS --- */}

      {/* If a specific management tool is active, show that instead of the dashboard */}
      {activeTool === 'locations' ? (
        <div className="space-y-10 animate-in fade-in duration-500">
           <div className="flex justify-between items-center">
              <button onClick={() => setActiveTool(null)} className="group flex items-center gap-3 text-slate-500 hover:text-primary transition-all font-bold">
                 <div className="w-10 h-10 rounded-full border border-slate-200 dark:border-slate-800 flex items-center justify-center group-hover:-translate-x-1 transition-transform">
                    <i className="fa-solid fa-arrow-left"></i>
                 </div>
                 Back to Control Panel
              </button>
              <div className="flex gap-4">
                 <button onClick={() => setIsAddingLocation(true)} className="bg-primary text-white px-8 py-4 rounded-2xl font-bold shadow-xl hover:bg-slate-800 transition-all active:scale-95">Add New Site</button>
              </div>
           </div>

           <div className="space-y-4">
              <h2 className="text-4xl font-serif font-bold">Business Registry</h2>
              <p className="text-slate-500">Managing {locations.length} official showroom and storage sites.</p>
           </div>

           <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {locations.map((loc) => (
                <div key={loc.id} className="group bg-white dark:bg-slate-900 p-8 rounded-[2.5rem] border border-slate-200 dark:border-slate-800 shadow-sm hover:shadow-xl transition-all relative overflow-hidden">
                   <div className="flex justify-between items-start mb-6">
                      <div className={`w-14 h-14 rounded-2xl flex items-center justify-center text-2xl shadow-sm ${loc.type === 'Showroom' ? 'bg-blue-50 text-blue-600 dark:bg-blue-900/20' : 'bg-emerald-50 text-emerald-600 dark:bg-emerald-900/20'}`}>
                         <i className={`fa-solid ${loc.type === 'Showroom' ? 'fa-shop' : 'fa-warehouse'}`}></i>
                      </div>
                      <button onClick={(e) => handleRemoveLocationRequest(e, loc)} className="w-10 h-10 bg-slate-50 dark:bg-slate-800 rounded-full flex items-center justify-center text-slate-300 hover:text-rose-500 transition-all shadow-sm opacity-0 group-hover:opacity-100">
                         <i className="fa-solid fa-trash-can"></i>
                      </button>
                   </div>
                   <div className="space-y-2">
                      <h4 className="text-xl font-bold">{loc.name}</h4>
                      <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-widest text-slate-400">
                         <span className={`w-2 h-2 rounded-full ${loc.type === 'Showroom' ? 'bg-blue-500' : 'bg-emerald-500'}`}></span>
                         {loc.type}
                      </div>
                   </div>
                   <div className="mt-8 space-y-4 pt-6 border-t border-slate-50 dark:border-slate-800">
                      <div className="flex items-center gap-4 text-sm text-slate-500">
                         <i className="fa-solid fa-location-dot text-slate-300 w-4"></i>
                         <span>{loc.address}</span>
                      </div>
                      <div className="flex items-center gap-4 text-sm text-slate-500">
                         <i className="fa-solid fa-phone text-slate-300 w-4"></i>
                         <span>{loc.phone}</span>
                      </div>
                      <div className="flex items-center gap-4 text-sm text-slate-500">
                         <i className="fa-solid fa-envelope text-slate-300 w-4"></i>
                         <span className="truncate">{loc.email}</span>
                      </div>
                   </div>
                </div>
              ))}
           </div>
        </div>
      ) : (
        <>
          {/* Main Header */}
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
            <div>
              <h1 className="text-4xl font-serif font-bold">Admin Console</h1>
              <p className="text-slate-500">Master system control for OldRoad Auto Operations.</p>
            </div>
            <div className="flex flex-wrap gap-3">
               <button onClick={toggleDarkMode} className="p-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl hover:text-accent transition-colors"><i className={`fa-solid ${darkMode ? 'fa-sun' : 'fa-moon'}`}></i></button>
               <button onClick={handleOpenSourcingModal} className="bg-primary text-white px-8 py-4 rounded-2xl font-bold shadow-xl hover:bg-slate-800 transition-all active:scale-95">List New Vehicle</button>
               <Link to="/dispatch" className="bg-white dark:bg-slate-800/40 text-accent border border-accent border-dashed px-6 py-4 rounded-2xl font-bold flex items-center gap-2 hover:bg-accent/5">Dispatch Queue</Link>
               <button onClick={() => setIsSettingsOpen(true)} className="bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 px-6 py-4 rounded-2xl font-bold hover:bg-slate-200 transition-all">System Settings</button>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2 bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 overflow-hidden shadow-sm">
              <div className="p-6 border-b border-slate-100 dark:border-slate-800 flex justify-between items-center">
                <h3 className="font-bold text-xl leading-none">Operational Activity</h3>
                <p className="text-slate-400 text-[10px] font-bold uppercase tracking-widest">Real-time Feed</p>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-left">
                  <thead className="bg-slate-50 dark:bg-slate-800/50 text-slate-500 text-[9px] uppercase font-bold tracking-[0.1em] border-b border-slate-100 dark:border-slate-800 sticky top-0 z-10 backdrop-blur-sm">
                    <tr>
                      <th className="px-6 py-4">Type</th>
                      <th className="px-6 py-4">Asset / Event</th>
                      <th className="px-6 py-4">Status</th>
                      <th className="px-6 py-4 text-right">Transaction</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                    {dashboardLogs.map((row) => (
                      <tr key={row.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/20 transition-colors group">
                        <td className="px-6 py-4">
                          <div className="flex items-center gap-3">
                            <div className="w-8 h-8 rounded-lg bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-xs">
                              {getActivityIcon(row.type)}
                            </div>
                            <div>
                              <p className="text-[10px] font-bold text-slate-900 dark:text-white uppercase leading-none">{row.type}</p>
                              <p className="text-[9px] text-slate-400 mt-0.5">{row.timestamp}</p>
                            </div>
                          </div>
                        </td>
                        <td className="px-6 py-4">
                          <div className="space-y-0.5">
                            <p className="font-bold text-sm">{row.car}</p>
                            <p className="text-[9px] text-slate-400 font-mono tracking-wider">{row.vin}</p>
                          </div>
                        </td>
                        <td className="px-6 py-4">
                          <span className={`text-[9px] font-bold px-3 py-1.5 rounded-full ${row.status === 'Completed' ? 'bg-emerald-100 text-emerald-700' : 'bg-amber-100 text-amber-700'}`}>
                            {row.status}
                          </span>
                        </td>
                        <td className="px-6 py-4 text-right">
                          <p className="text-xs font-bold text-slate-900 dark:text-white">{row.val}</p>
                          <p className="text-[8px] text-slate-400 uppercase tracking-widest">{row.loc}</p>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            <div className="space-y-8">
               <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-8 shadow-sm">
                <h3 className="font-bold text-xl mb-6">Management Tools</h3>
                <div className="grid grid-cols-1 gap-4">
                  {[
                    { label: 'Listed Vehicle Manager', icon: 'fa-car-on', count: `${vehicles.length} active`, id: 'inventory' },
                    { label: 'Manage Locations', icon: 'fa-map-location-dot', count: `${locations.length} active`, id: 'locations' }
                  ].map(item => (
                    <button key={item.id} onClick={() => setActiveTool(item.id as ManagementToolType)} className="flex items-center gap-4 p-4 rounded-2xl bg-slate-50 dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700 transition-all text-left group">
                      <div className="w-12 h-12 bg-white dark:bg-slate-900 rounded-xl flex items-center justify-center text-accent shadow-sm group-hover:scale-110 transition-transform"><i className={`fa-solid ${item.icon}`}></i></div>
                      <div><p className="font-bold text-sm">{item.label}</p><p className="text-[10px] text-slate-500 font-medium">{item.count}</p></div>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </>
      )}

      {/* Sourcing Modal (Asset Listing) */}
      {isSourcingModalOpen && (
        <div className="fixed inset-0 z-[140] flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm" onClick={() => setIsSourcingModalOpen(false)}></div>
          <div className="relative bg-white dark:bg-slate-900 w-full max-w-xl rounded-[2.5rem] p-8 shadow-2xl border border-slate-200 dark:border-slate-800 animate-in zoom-in-95 duration-200">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-2xl font-serif font-bold">List Ready Asset</h2>
              <button onClick={() => setIsSourcingModalOpen(false)} className="w-10 h-10 rounded-full bg-slate-100 dark:bg-slate-800 flex items-center justify-center"><i className="fa-solid fa-xmark"></i></button>
            </div>
            <div className="mb-6 relative">
              <i className="fa-solid fa-magnifying-glass absolute left-4 top-1/2 -translate-y-1/2 text-slate-400"></i>
              <input type="text" placeholder="Search arrivals..." className="w-full pl-12 pr-4 py-3 bg-slate-50 dark:bg-slate-800 rounded-xl outline-none" value={sourcingSearch} onChange={e => setSourcingSearch(e.target.value)} />
            </div>
            <div className="space-y-4 max-h-[50vh] overflow-y-auto pr-2">
              {filteredArrivals.map(arrival => (
                <div key={arrival.id} onClick={() => arrival.status === 'Ready to Sell' && handleSelectFromDispatch(arrival)} className={`p-4 rounded-xl border-2 transition-all ${arrival.status === 'Ready to Sell' ? 'cursor-pointer hover:border-accent' : 'opacity-40 grayscale pointer-events-none'}`}>
                   <p className="font-bold">{arrival.year} {arrival.make} {arrival.model}</p>
                   <p className="text-[10px] font-mono">{arrival.vin}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Editor Modal */}
      {isVehicleEditorOpen && editingVehicle && (
        <div className="fixed inset-0 z-[140] flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm" onClick={() => setIsVehicleEditorOpen(false)}></div>
          <div className="relative bg-white dark:bg-slate-900 w-full max-w-xl rounded-[2.5rem] p-10 shadow-2xl animate-in zoom-in-95 duration-200 overflow-y-auto max-h-[90vh]">
            <h2 className="text-3xl font-serif font-bold mb-8">Finalize Showroom Listing</h2>
            <form onSubmit={handleSaveVehicle} className="space-y-6">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-slate-400 uppercase">Price (CAD)</label>
                  <input type="number" required className="w-full p-4 bg-slate-50 dark:bg-slate-800 rounded-2xl font-bold" value={editingVehicle.price} onChange={e => setEditingVehicle({...editingVehicle, price: parseInt(e.target.value)})} />
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-slate-400 uppercase">Mileage (KM)</label>
                  <input type="number" required className="w-full p-4 bg-slate-50 dark:bg-slate-800 rounded-2xl font-bold" value={editingVehicle.km} onChange={e => setEditingVehicle({...editingVehicle, km: parseInt(e.target.value)})} />
                </div>
              </div>
              <div className="space-y-2">
                 <label className="text-[10px] font-bold text-slate-400 uppercase">Description</label>
                 <textarea className="w-full p-4 bg-slate-50 dark:bg-slate-800 rounded-2xl text-sm h-32" value={editingVehicle.description} onChange={e => setEditingVehicle({...editingVehicle, description: e.target.value})} />
              </div>
              <div className="space-y-4">
                <label className="text-[10px] font-bold text-slate-400 uppercase">Gallery</label>
                <div onClick={() => fileInputRef.current?.click()} className="border-2 border-dashed rounded-2xl p-8 flex flex-col items-center justify-center cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-800">
                   <i className="fa-solid fa-cloud-arrow-up text-3xl mb-2 text-slate-300"></i>
                   <p className="text-xs font-bold text-slate-400">Attach Photos</p>
                   <input type="file" ref={fileInputRef} className="hidden" multiple accept="image/*" onChange={handleImageUpload} />
                </div>
                {editingVehicle.images && (
                  <div className="grid grid-cols-4 gap-2">
                    {editingVehicle.images.map((img, idx) => (
                      <div key={idx} className="relative aspect-square rounded-xl overflow-hidden border border-slate-100">
                        <img src={img} className="w-full h-full object-cover" />
                        <button type="button" onClick={() => removeUploadImage(idx)} className="absolute top-1 right-1 w-6 h-6 bg-rose-500 text-white rounded-full flex items-center justify-center text-[10px]"><i className="fa-solid fa-xmark"></i></button>
                      </div>
                    ))}
                  </div>
                )}
              </div>
              <button type="submit" className="w-full py-5 bg-primary text-white rounded-[1.5rem] font-bold shadow-xl active:scale-95">Publish Listing</button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default AdminDashboard;
