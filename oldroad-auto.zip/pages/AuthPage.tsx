
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

interface AuthPageProps {
  onLogin: (email: string) => void;
}

const AuthPage: React.FC<AuthPageProps> = ({ onLogin }) => {
  const [isLogin, setIsLogin] = useState(true);
  const [email, setEmail] = useState('');
  const navigate = useNavigate();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onLogin(email);
    navigate('/dashboard');
  };

  return (
    <div className="max-w-md mx-auto px-4 py-20">
      <div className="bg-white dark:bg-slate-900 rounded-3xl shadow-xl border border-slate-200 dark:border-slate-800 p-8">
        <div className="text-center mb-10">
          <h2 className="text-3xl font-serif font-bold mb-2">
            {isLogin ? 'Welcome Back' : 'Create Account'}
          </h2>
          <p className="text-slate-500">
            {isLogin ? 'Access your dashboard and favorites.' : 'Join the OldRoad Auto community.'}
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          {!isLogin && (
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <label className="text-sm font-bold text-slate-500 uppercase">First Name</label>
                <input type="text" required className="w-full p-3 bg-slate-50 dark:bg-slate-800 rounded-xl" />
              </div>
              <div className="space-y-2">
                <label className="text-sm font-bold text-slate-500 uppercase">Last Name</label>
                <input type="text" required className="w-full p-3 bg-slate-50 dark:bg-slate-800 rounded-xl" />
              </div>
            </div>
          )}
          
          <div className="space-y-2">
            <label className="text-sm font-bold text-slate-500 uppercase">Email Address</label>
            <input 
              type="email" 
              required 
              className="w-full p-3 bg-slate-50 dark:bg-slate-800 rounded-xl outline-none focus:ring-2 focus:ring-accent"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="e.g. admin@oldroad.auto"
            />
          </div>

          <div className="space-y-2">
            <label className="text-sm font-bold text-slate-500 uppercase">Password</label>
            <input type="password" required className="w-full p-3 bg-slate-50 dark:bg-slate-800 rounded-xl outline-none focus:ring-2 focus:ring-accent" />
          </div>

          {isLogin && (
            <div className="text-right">
              <a href="#" className="text-sm text-accent hover:underline">Forgot password?</a>
            </div>
          )}

          {!isLogin && (
            <div className="flex items-center gap-2">
              <input type="checkbox" className="w-4 h-4 rounded text-accent" />
              <label className="text-sm text-slate-500">I agree to receive marketing updates.</label>
            </div>
          )}

          <button className="w-full bg-primary text-white py-4 rounded-2xl font-bold text-lg hover:bg-slate-800 transition-all shadow-lg">
            {isLogin ? 'Sign In' : 'Register Now'}
          </button>
        </form>

        <div className="mt-8 text-center pt-8 border-t border-slate-100 dark:border-slate-800">
          <p className="text-slate-500">
            {isLogin ? "Don't have an account?" : "Already have an account?"}
            <button 
              onClick={() => setIsLogin(!isLogin)}
              className="ml-2 font-bold text-accent hover:underline"
            >
              {isLogin ? 'Sign Up' : 'Log In'}
            </button>
          </p>
        </div>
      </div>

      <div className="mt-8 p-4 bg-amber-50 dark:bg-amber-900/20 rounded-xl text-center text-sm border border-amber-100 dark:border-amber-800">
        <p className="text-amber-800 dark:text-amber-300">
          <i className="fa-solid fa-circle-info mr-2"></i>
          Test credentials: <b>admin@oldroad.auto</b>, <b>sales@oldroad.auto</b>, or <b>customer@gmail.com</b>
        </p>
      </div>
    </div>
  );
};

export default AuthPage;
