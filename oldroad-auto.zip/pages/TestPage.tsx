
import React, { useState, useMemo, useCallback, useRef, useEffect } from 'react';
import { User, UserRole, FuelType, VehicleStatus } from '../types';
import { Navigate, Link } from 'react-router-dom';

interface TestPageProps { user: User | null; }

interface ArrivalDocument {
  id: string;
  name: string;
  type: 'Invoice' | 'Title' | 'Shipping' | 'Customs' | 'Other';
  date: string;
  url: string;
}

type VehicleCategory = 'Minivan' | 'Hatchback' | 'Convertible' | 'Wagon' | 'SUV / Crossover' | 'Truck' | 'Sedan' | 'Coupe';

interface ArrivalItem {
  id: string;
  year: number | string;
  make: string;
  model: string;
  trim: string;
  color: string;
  vin: string;
  lotNumber: string;
  paymentStatus: 'Pending' | 'Paid' | 'Picked Up' | 'Delivered' | 'Fixing' | 'Ready to Sell';
  fuelType: FuelType;
  category: VehicleCategory;
  hasTitle: 'YES' | 'NO' | 'TBO';
  titleType: 'Clean' | 'Salvage' | 'Rebuild';
  hasKeys: boolean;
  price: number;
  destination: string;
  images: string[];
  documents: ArrivalDocument[];
  notes: string;
  seller: { name: string; phone: string; address: string; };
  transporter: { driver: string; phone: string; address: string; };
  timeline: { 
    purchase: string; 
    paid: string; 
    pickup: string; 
    delivery: string; 
    fixing: string; 
    ready: string; 
  };
}

interface DispatchSettings {
  autoCalculateETA: boolean;
  overdueAlertDays: number;
  defaultDestination: string;
  requireKeysForDelivery: boolean;
  requireTitleForReady: boolean;
  standardPrepTime: number; // days
}

const DESTINATIONS = ['Main Showroom', 'East Warehouse', 'In Transit', 'Detailing Shop', 'Paint Shop', 'Auction Yard'];
const CATEGORIES: VehicleCategory[] = ['Minivan', 'Hatchback', 'Convertible', 'Wagon', 'SUV / Crossover', 'Truck', 'Sedan', 'Coupe'];
const INITIAL_COLORS = [
  'Black', 'White', 'Silver', 'Grey', 'Blue', 'Red', 'Green', 'Yellow', 
  'Orange', 'Brown', 'Beige', 'Purple', 'Gold', 'Bronze', 'Copper', 'Burgundy', 'Other'
].sort();

const ITEMS_PER_PAGE = 10;

const INITIAL_MAKES = ['Honda', 'Toyota', 'Tesla', 'Ford', 'GMC', 'BMW', 'Mercedes-Benz', 'Chevrolet', 'Audi', 'Lexus', 'Nissan', 'Jeep', 'Infiniti', 'Mitsubishi', 'Datsun'].sort();
const INITIAL_MODELS_BY_MAKE: Record<string, string[]> = {
  'Honda': ['Accord', 'Civic', 'CR-V', 'Pilot', 'Odyssey'],
  'Toyota': ['Camry', 'Corolla', 'RAV4', 'Highlander', 'Tacoma', 'Sienna'],
  'Tesla': ['Model 3', 'Model Y', 'Model S', 'Model X', 'Cybertruck'],
  'Ford': ['F-150', 'Mustang', 'Explorer', 'Escape', 'Bronco'],
  'GMC': ['Sierra', 'Yukon', 'Terrain', 'Acadia'],
  'BMW': ['3 Series', '5 Series', 'X3', 'X5', 'M3'],
  'Mercedes-Benz': ['C-Class', 'E-Class', 'GLC', 'GLE', 'S-Class'],
  'Chevrolet': ['Silverado', 'Equinox', 'Malibu', 'Tahoe', 'Corvette'],
  'Audi': ['A4', 'A6', 'Q5', 'Q7', 'e-tron'],
  'Lexus': ['RX', 'ES', 'NX', 'GX', 'IS'],
  'Nissan': ['Altima', 'Rogue', 'Sentra', 'Pathfinder', 'Frontier'],
  'Jeep': ['Wrangler', 'Grand Cherokee', 'Cherokee', 'Compass'],
  'Infiniti': ['Q50', 'QX60', 'QX80', 'QX50'],
  'Mitsubishi': ['Outlander', 'Eclipse Cross', 'Mirage', 'Lancer'],
  'Datsun': ['240Z', '510', '280ZX', 'B210'],
};

const INITIAL_TRANSPORTERS = ['Quick Tow LLC', 'Reliable Auto Shippers', 'Canadian Logistics Group', 'East Coast Towing'];

const STATUS_PROGRESSION: Record<ArrivalItem['paymentStatus'], number> = {
  'Pending': 0,
  'Paid': 1,
  'Picked Up': 2,
  'Delivered': 3,
  'Fixing': 4,
  'Ready to Sell': 5
};

const LISTING_SORT_ORDER: Record<ArrivalItem['paymentStatus'], number> = {
  'Delivered': 0,
  'Fixing': 1,
  'Picked Up': 2,
  'Paid': 3,
  'Pending': 4,
  'Ready to Sell': 5
};

const SearchableSelect: React.FC<{
  value: string;
  options: string[];
  onChange: (val: string) => void;
  placeholder: string;
}> = ({ value, options, onChange, placeholder }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [search, setSearch] = useState('');
  const wrapperRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (wrapperRef.current && !wrapperRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const filteredOptions = useMemo(() => {
    return options.filter(opt => opt.toLowerCase().includes(search.toLowerCase()));
  }, [options, search]);

  return (
    <div className="relative inline-block" ref={wrapperRef}>
      <button 
        type="button"
        onClick={() => setIsOpen(!isOpen)}
        className={`text-2xl font-serif font-bold bg-transparent outline-none cursor-pointer text-left flex items-center gap-2 group whitespace-nowrap transition-colors ${value ? 'text-slate-900' : 'text-slate-300'}`}
      >
        {value || placeholder}
        <i className={`fa-solid fa-chevron-down text-[10px] text-slate-300 group-hover:text-blue-500 transition-all ${isOpen ? 'rotate-180' : ''}`}></i>
      </button>
      
      {isOpen && (
        <div className="absolute z-[200] top-full left-0 mt-3 w-64 bg-white border border-slate-200 rounded-2xl shadow-2xl overflow-hidden animate-in fade-in slide-in-from-top-2 duration-200">
          <div className="p-3 border-b border-slate-100 bg-slate-50/50">
            <div className="relative">
              <i className="fa-solid fa-magnifying-glass absolute left-3 top-1/2 -translate-y-1/2 text-slate-300 text-xs"></i>
              <input 
                autoFocus
                type="text" 
                className="w-full pl-8 pr-3 py-2 bg-white rounded-lg text-sm outline-none focus:ring-2 focus:ring-blue-500/20 border border-slate-200"
                placeholder="Type to filter..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
              />
            </div>
          </div>
          <div className="max-h-60 overflow-y-auto custom-scrollbar">
            {filteredOptions.map(opt => (
              <button
                key={opt}
                type="button"
                onClick={() => {
                  onChange(opt);
                  setIsOpen(false);
                  setSearch('');
                }}
                className={`w-full text-left px-4 py-3 text-sm font-medium hover:bg-blue-50 transition-colors uppercase tracking-wide ${value === opt ? 'bg-blue-50 text-blue-600 font-bold' : 'text-slate-600'}`}
              >
                {opt}
              </button>
            ))}
            {filteredOptions.length === 0 && (
              <div className="px-4 py-8 text-center text-xs text-slate-400 italic">No results for "{search}"</div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

const DispatchPage: React.FC<TestPageProps> = ({ user }) => {
  const [view, setView] = useState<'dashboard' | 'detail' | 'settings'>('dashboard');
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<ArrivalItem['paymentStatus'] | 'All'>('All');
  const [makeFilter, setMakeFilter] = useState('All');
  const [modelFilter, setModelFilter] = useState('All');
  const [currentPage, setCurrentPage] = useState(1);
  
  const [isLightboxOpen, setIsLightboxOpen] = useState(false);
  const [activeImageIndex, setActiveImageIndex] = useState(0);
  const [zoomLevel, setZoomLevel] = useState(1);

  const [isMediaManagerOpen, setIsMediaManagerOpen] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const documentFileInputRef = useRef<HTMLInputElement>(null);
  const [pendingDocType, setPendingDocType] = useState<ArrivalDocument['type']>('Other');

  const [dispatchSettings, setDispatchSettings] = useState<DispatchSettings>({
    autoCalculateETA: true,
    overdueAlertDays: 2,
    defaultDestination: 'Main Showroom',
    requireKeysForDelivery: true,
    requireTitleForReady: true,
    standardPrepTime: 3
  });

  const [makes, setMakes] = useState<string[]>(INITIAL_MAKES);
  const [modelsByMake, setModelsByMake] = useState<Record<string, string[]>>(INITIAL_MODELS_BY_MAKE);
  const [colors, setColors] = useState<string[]>(INITIAL_COLORS);
  const [transporters, setTransporters] = useState<string[]>(INITIAL_TRANSPORTERS);
  
  const [newMakeName, setNewMakeName] = useState('');
  const [selectedMakeForModel, setSelectedMakeForModel] = useState('');
  const [newModelName, setNewModelName] = useState('');
  const [newColorName, setNewColorName] = useState('');
  const [newTransporterName, setNewTransporterName] = useState('');
  const [catalogRegistrySearch, setCatalogRegistrySearch] = useState('');
  const [colorRegistrySearch, setColorRegistrySearch] = useState('');
  const [transporterRegistrySearch, setTransporterRegistrySearch] = useState('');

  const [deleteConfirm, setDeleteConfirm] = useState<{
    isOpen: boolean;
    type: 'make' | 'model' | 'color' | 'transporter';
    targetName: string;
    parentMake?: string;
  }>({ isOpen: false, type: 'make', targetName: '' });

  const [isSavingSettings, setIsSavingSettings] = useState(false);
  
  const [arrivals, setArrivals] = useState<ArrivalItem[]>([
    {
      id: 'a1',
      year: 2021,
      make: 'Honda',
      model: 'Accord',
      trim: 'Sport',
      color: 'White',
      vin: '3A004321',
      lotNumber: '58432190',
      paymentStatus: 'Paid',
      fuelType: 'Gas',
      category: 'Sedan',
      hasTitle: 'YES',
      titleType: 'Clean',
      hasKeys: true,
      price: 12500,
      destination: 'Main Showroom',
      images: [
        'https://images.unsplash.com/photo-1592198084033-aade902d1aae?auto=format&fit=crop&q=80&w=1200&h=800',
        'https://images.unsplash.com/photo-1542362567-b05503f3f5f4?auto=format&fit=crop&q=80&w=1200&h=800',
        'https://images.unsplash.com/photo-1503376780353-7e6692767b70?auto=format&fit=crop&q=80&w=1200&h=800'
      ],
      documents: [
        { id: 'd1', name: 'Purchase Invoice', type: 'Invoice', date: '2026-01-12', url: '#' },
        { id: 'd2', name: 'Bill of Sale', type: 'Other', date: '2026-01-13', url: '#' }
      ],
      notes: 'Customer requested secondary inspection of front rotors.',
      seller: { name: 'Copart Dallas', phone: '214-555-0123', address: 'Dallas, TX' },
      transporter: { driver: 'Quick Tow LLC', phone: '214-555-9988', address: '123 Towing Ln, Dallas TX' },
      timeline: { purchase: '2026-01-12', paid: '2026-01-13', pickup: '2026-01-13', delivery: '', fixing: '', ready: '' }
    },
    {
      id: 'a2',
      year: 2026,
      make: 'Toyota',
      model: 'Camry',
      trim: 'XSE',
      color: 'Silver',
      vin: 'TY009988',
      lotNumber: '11223344',
      paymentStatus: 'Fixing',
      fuelType: 'Hybrid',
      category: 'Sedan',
      hasTitle: 'NO',
      titleType: 'Salvage',
      hasKeys: true,
      price: 28500,
      destination: 'East Warehouse',
      images: [
        'https://images.unsplash.com/photo-1621007947382-bb3c3994e3fb?auto=format&fit=crop&q=80&w=1200&h=800',
        'https://images.unsplash.com/photo-1581092160562-40aa08e78837?auto=format&fit=crop&q=80&w=1200&h=800'
      ],
      documents: [],
      notes: '',
      seller: { name: 'Local Auction', phone: '555-0199', address: 'Toronto, ON' },
      transporter: { driver: 'TBD', phone: '', address: '' },
      timeline: { purchase: '2026-02-10', paid: '2026-02-11', pickup: '', delivery: '', fixing: '2026-02-14', ready: '' }
    }
  ]);

  const [activeVehicle, setActiveVehicle] = useState<ArrivalItem | null>(null);

  if (!user || (user.role !== UserRole.ADMIN && user.role !== UserRole.SALES)) {
    return <Navigate to="/auth" />;
  }

  const handleAddMake = () => {
    if (!newMakeName.trim()) return;
    const formatted = newMakeName.trim();
    if (makes.includes(formatted)) {
      alert("This make already exists.");
      return;
    }
    setMakes(prev => [...prev, formatted].sort());
    setModelsByMake(prev => ({ ...prev, [formatted]: [] }));
    setNewMakeName('');
  };

  const handleAddModel = () => {
    if (!selectedMakeForModel || !newModelName.trim()) return;
    const formatted = newModelName.trim();
    const existingModels = modelsByMake[selectedMakeForModel] || [];
    if (existingModels.includes(formatted)) {
      alert("This model already exists for this make.");
      return;
    }
    setModelsByMake(prev => ({
      ...prev,
      [selectedMakeForModel]: [...existingModels, formatted].sort()
    }));
    setNewModelName('');
  };

  const handleAddColor = () => {
    if (!newColorName.trim()) return;
    const formatted = newColorName.trim();
    if (colors.includes(formatted)) {
      alert("This color already exists.");
      return;
    }
    setColors(prev => [...prev, formatted].sort());
    setNewColorName('');
  };

  const handleAddTransporter = () => {
    if (!newTransporterName.trim()) return;
    const formatted = newTransporterName.trim();
    if (transporters.includes(formatted)) {
      alert("This transporter already exists.");
      return;
    }
    setTransporters(prev => [...prev, formatted].sort());
    setNewTransporterName('');
  };

  const requestDeleteModel = (e: React.MouseEvent, make: string, model: string) => {
    e.stopPropagation();
    setDeleteConfirm({
      isOpen: true,
      type: 'model',
      targetName: model,
      parentMake: make
    });
  };

  const requestDeleteMake = (e: React.MouseEvent, make: string) => {
    e.stopPropagation();
    setDeleteConfirm({
      isOpen: true,
      type: 'make',
      targetName: make
    });
  };

  const requestDeleteColor = (e: React.MouseEvent, color: string) => {
    e.stopPropagation();
    setDeleteConfirm({
      isOpen: true,
      type: 'color',
      targetName: color
    });
  };

  const requestDeleteTransporter = (e: React.MouseEvent, transporter: string) => {
    e.stopPropagation();
    setDeleteConfirm({
      isOpen: true,
      type: 'transporter',
      targetName: transporter
    });
  };

  const finalizeDeletion = () => {
    if (deleteConfirm.type === 'model' && deleteConfirm.parentMake) {
      const { parentMake, targetName } = deleteConfirm;
      setModelsByMake(prev => ({
        ...prev,
        [parentMake]: prev[parentMake].filter(m => m !== targetName)
      }));
    } else if (deleteConfirm.type === 'make') {
      const { targetName } = deleteConfirm;
      setMakes(prev => prev.filter(m => m !== targetName));
      setModelsByMake(prev => {
        const next = { ...prev };
        delete next[targetName];
        return next;
      });
    } else if (deleteConfirm.type === 'color') {
      const { targetName } = deleteConfirm;
      setColors(prev => prev.filter(c => c !== targetName));
    } else if (deleteConfirm.type === 'transporter') {
      const { targetName } = deleteConfirm;
      setTransporters(prev => prev.filter(t => t !== targetName));
    }
    setDeleteConfirm(prev => ({ ...prev, isOpen: false }));
  };

  const stats = useMemo(() => ({
    total: arrivals.length,
    delivered: arrivals.filter(a => a.paymentStatus === 'Delivered').length,
    fixing: arrivals.filter(a => a.paymentStatus === 'Fixing').length,
    ready: arrivals.filter(a => a.paymentStatus === 'Ready to Sell').length,
  }), [arrivals]);

  const filteredArrivals = useMemo(() => {
    return arrivals.filter(car => {
      const matchesSearch = `${car.vin} ${car.lotNumber}`.toLowerCase().includes(search.toLowerCase());
      const matchesMake = makeFilter === 'All' || car.make === makeFilter;
      const matchesModel = modelFilter === 'All' || car.model === modelFilter;
      const matchesStatus = statusFilter === 'All' || car.paymentStatus === statusFilter;
      return matchesSearch && matchesMake && matchesModel && matchesStatus;
    }).sort((a, b) => {
      const rankA = LISTING_SORT_ORDER[a.paymentStatus];
      const rankB = LISTING_SORT_ORDER[b.paymentStatus];
      return rankA - rankB;
    });
  }, [arrivals, search, statusFilter, makeFilter, modelFilter]);

  const filteredCatalogRegistry = useMemo(() => {
    return makes.filter(m => {
      const hasMakeMatch = m.toLowerCase().includes(catalogRegistrySearch.toLowerCase());
      const hasModelMatch = (modelsByMake[m] || []).some(mod => mod.toLowerCase().includes(catalogRegistrySearch.toLowerCase()));
      return hasMakeMatch || hasModelMatch;
    });
  }, [makes, modelsByMake, catalogRegistrySearch]);

  const filteredColorRegistry = useMemo(() => {
    return colors.filter(c => c.toLowerCase().includes(colorRegistrySearch.toLowerCase()));
  }, [colors, colorRegistrySearch]);

  const filteredTransporterRegistry = useMemo(() => {
    return transporters.filter(t => t.toLowerCase().includes(transporterRegistrySearch.toLowerCase()));
  }, [transporters, transporterRegistrySearch]);

  useEffect(() => {
    setCurrentPage(1);
  }, [search, statusFilter, makeFilter, modelFilter]);

  const paginatedArrivals = useMemo(() => {
    const startIndex = (currentPage - 1) * ITEMS_PER_PAGE;
    return filteredArrivals.slice(startIndex, startIndex + ITEMS_PER_PAGE);
  }, [filteredArrivals, currentPage]);

  const totalPages = Math.ceil(filteredArrivals.length / ITEMS_PER_PAGE);

  const handleAddVehicle = () => {
    const newVehicle: ArrivalItem = {
      id: `v-new-${Math.random().toString(36).substr(2, 9)}`,
      year: '',
      make: '',
      model: '',
      trim: '',
      color: '',
      vin: '',
      lotNumber: '',
      paymentStatus: 'Pending',
      fuelType: 'Gas',
      category: 'SUV / Crossover',
      hasTitle: 'NO',
      titleType: 'Clean',
      hasKeys: false,
      price: 0,
      destination: dispatchSettings.defaultDestination,
      images: [],
      documents: [],
      notes: '',
      seller: { name: '', phone: '', address: '' },
      transporter: { driver: '', phone: '', address: '' },
      timeline: { purchase: '', paid: '', pickup: '', delivery: '', fixing: '', ready: '' }
    };
    setActiveVehicle(newVehicle);
    setView('detail');
  };

  const handleOpenDetail = (car: ArrivalItem) => {
    setActiveVehicle({ ...car });
    setView('detail');
  };

  const updatePaymentStatus = (e: React.ChangeEvent<HTMLSelectElement>, id: string) => {
    e.stopPropagation();
    const newStatus = e.target.value as ArrivalItem['paymentStatus'];
    setArrivals(prev => prev.map(a => a.id === id ? { ...a, paymentStatus: newStatus } : a));
  };

  const updateDestination = (e: React.ChangeEvent<HTMLSelectElement>, id: string) => {
    e.stopPropagation();
    const newDest = e.target.value;
    setArrivals(prev => prev.map(a => a.id === id ? { ...a, destination: newDest } : a));
  };

  const cycleTitle = (e: React.MouseEvent, id: string) => {
    e.stopPropagation();
    setArrivals(prev => prev.map(a => {
      if (a.id === id) {
        let next: ArrivalItem['hasTitle'] = 'YES';
        if (a.hasTitle === 'YES') next = 'TBO';
        else if (a.hasTitle === 'TBO') next = 'NO';
        return { ...a, hasTitle: next };
      }
      return a;
    }));
  };

  const toggleKeys = (e: React.MouseEvent, id: string) => {
    e.stopPropagation();
    setArrivals(prev => prev.map(a => a.id === id ? { ...a, hasKeys: !a.hasKeys } : a));
  };

  const updateStatus = (e: React.MouseEvent, id: string, newStatus: ArrivalItem['paymentStatus']) => {
    e.stopPropagation();
    setArrivals(prev => prev.map(a => a.id === id ? { ...a, paymentStatus: newStatus } : a));
  };

  const formatDate = (dateStr: string) => {
    if (!dateStr) return 'TBD';
    const d = new Date(dateStr + 'T00:00:00');
    return `${d.getMonth() + 1}/${d.getDate()}/${d.getFullYear()}`;
  };

  const isOverdue = (dateStr: string) => {
    if (!dateStr) return false;
    const date = new Date(dateStr);
    const today = new Date();
    today.setHours(0,0,0,0);
    return date < today;
  };

  const openLightbox = (index: number) => {
    setActiveImageIndex(index);
    setZoomLevel(1);
    setIsLightboxOpen(true);
  };

  const closeLightbox = () => {
    setIsLightboxOpen(false);
    setZoomLevel(1);
  };

  const handleZoomIn = (e: React.MouseEvent) => {
    e.stopPropagation();
    setZoomLevel(prev => Math.min(prev + 0.5, 3));
  };

  const handleZoomOut = (e: React.MouseEvent) => {
    e.stopPropagation();
    setZoomLevel(prev => Math.max(prev - 0.5, 1));
  };

  const nextImage = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!activeVehicle) return;
    setActiveImageIndex(prev => (prev + 1) % activeVehicle.images.length);
    setZoomLevel(1);
  };

  const prevImage = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!activeVehicle) return;
    setActiveImageIndex(prev => (prev - 1 + activeVehicle.images.length) % activeVehicle.images.length);
    setZoomLevel(1);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0 || !activeVehicle) return;

    Array.from(files).forEach((file: File) => {
      const reader = new FileReader();
      reader.onload = (event) => {
        const base64String = event.target?.result as string;
        if (base64String) {
          setArrivals(prev => prev.map(a => {
            if (a.id === activeVehicle.id) {
              const updatedImages = [...a.images, base64String];
              setActiveVehicle(curr => curr ? { ...curr, images: updatedImages } : null);
              return { ...a, images: updatedImages };
            }
            return a;
          }));
        }
      };
      reader.readAsDataURL(file);
    });
    
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const handleDocumentFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !activeVehicle) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const base64String = event.target?.result as string;
      if (base64String) {
        const newDoc: ArrivalDocument = {
          id: Math.random().toString(36).substr(2, 9),
          name: file.name,
          type: pendingDocType,
          date: new Date().toISOString().split('T')[0],
          url: base64String
        };
        setActiveVehicle(prev => {
          if (!prev) return null;
          return { ...prev, documents: [...(prev.documents || []), newDoc] };
        });
      }
    };
    reader.readAsDataURL(file);

    if (documentFileInputRef.current) documentFileInputRef.current.value = '';
  };

  const handleAddDocument = (type: ArrivalDocument['type']) => {
    setPendingDocType(type);
    documentFileInputRef.current?.click();
  };

  const handleRemoveDocument = (docId: string) => {
    if (!activeVehicle) return;
    setActiveVehicle(prev => {
      if (!prev) return null;
      return { ...prev, documents: (prev.documents || []).filter(d => d.id !== docId) };
    });
  };

  const triggerFileUpload = () => {
    fileInputRef.current?.click();
  };

  const handleRemoveMedia = (index: number) => {
    if (!activeVehicle) return;
    const updatedImages = activeVehicle.images.filter((_, i) => i !== index);
    const updatedVehicle = { ...activeVehicle, images: updatedImages };
    
    setActiveVehicle(updatedVehicle);
    setArrivals(prev => prev.map(a => a.id === activeVehicle.id ? updatedVehicle : a));
  };

  const handleEditVehicle = (field: string, value: any) => {
    if (!activeVehicle) return;
    
    setActiveVehicle(prev => {
      if (!prev) return null;
      if (field.includes('.')) {
        const [parent, child] = field.split('.');
        return {
          ...prev,
          [parent]: {
            ...(prev[parent as keyof ArrivalItem] as any),
            [child]: value
          }
        };
      }
      return { ...prev, [field]: value };
    });
  };

  const handleSaveChanges = () => {
    if (!activeVehicle) return;
    setArrivals(prev => {
      const exists = prev.some(a => a.id === activeVehicle.id);
      if (exists) {
        return prev.map(a => a.id === activeVehicle.id ? activeVehicle : a);
      } else {
        return [activeVehicle, ...prev];
      }
    });
    alert("Changes saved to inventory.");
    setView('dashboard');
  };

  const handleSaveDispatchSettings = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSavingSettings(true);
    setTimeout(() => {
      setIsSavingSettings(false);
      setView('dashboard');
      alert("Dispatch operational configuration updated.");
    }, 1000);
  };

  if (view === 'settings') {
    return (
      <div className="bg-[#f8fafc] min-h-screen text-slate-900 p-6 md:p-10 animate-in fade-in duration-500">
        {deleteConfirm.isOpen && (
          <div className="fixed inset-0 z-[300] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-200">
             <div className="bg-white dark:bg-slate-900 w-full max-w-md rounded-[2.5rem] p-8 shadow-2xl border border-slate-100 dark:border-slate-800 animate-in zoom-in-95 duration-200">
                <div className="w-16 h-16 bg-rose-50 dark:bg-rose-900/20 text-rose-500 rounded-2xl flex items-center justify-center text-2xl mb-6 mx-auto">
                  <i className="fa-solid fa-triangle-exclamation"></i>
                </div>
                <div className="text-center space-y-4 mb-8">
                  <h3 className="text-2xl font-serif font-bold text-slate-900 dark:text-white">Final Confirmation</h3>
                  <p className="text-slate-500 dark:text-slate-400 leading-relaxed font-medium">
                    Are you sure do you want to delete <span className="text-rose-500 font-bold">{deleteConfirm.targetName}</span>?
                  </p>
                  {deleteConfirm.type === 'make' && (
                    <p className="text-[10px] font-bold text-rose-400 uppercase tracking-widest bg-rose-50 dark:bg-rose-950/30 py-2 rounded-xl">
                      Warning: All associated models will be removed.
                    </p>
                  )}
                </div>
                <div className="flex gap-3">
                  <button 
                    onClick={() => setDeleteConfirm(prev => ({...prev, isOpen: false}))}
                    className="flex-1 py-4 bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 rounded-2xl font-bold hover:bg-slate-200 transition-all active:scale-95"
                  >
                    Cancel
                  </button>
                  <button 
                    onClick={finalizeDeletion}
                    className="flex-1 py-4 bg-rose-500 text-white rounded-2xl font-bold hover:bg-rose-600 transition-all shadow-xl shadow-rose-500/20 active:scale-95"
                  >
                    Delete Entry
                  </button>
                </div>
             </div>
          </div>
        )}

        <div className="max-w-[800px] mx-auto space-y-10">
          <div className="flex justify-between items-center">
            <button onClick={() => setView('dashboard')} className="group bg-white border border-slate-200 text-slate-700 px-6 py-3 rounded-2xl font-bold text-sm flex items-center gap-2 hover:bg-slate-50 transition-all shadow-sm active:scale-95">
              <i className="fa-solid fa-arrow-left group-hover:-translate-x-1 transition-transform"></i> Back to Dispatch
            </button>
            <h1 className="text-3xl font-serif font-bold text-slate-900">Dispatch Settings</h1>
          </div>

          <form onSubmit={handleSaveDispatchSettings} className="space-y-10">
            <div className="bg-white rounded-[2.5rem] p-8 md:p-12 border border-slate-100 shadow-xl space-y-10">
              <div className="space-y-2">
                <h3 className="text-xs font-bold text-slate-400 uppercase tracking-widest flex items-center gap-2">
                  <i className="fa-solid fa-tags text-purple-500"></i> Vehicle Catalog Management
                </h3>
                <p className="text-xs text-slate-500">Maintain the list of supported vehicle manufacturers and models.</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div className="space-y-4">
                  <label className="text-[10px] font-bold text-slate-400 uppercase">Register New Manufacturer</label>
                  <div className="flex gap-2">
                    <input 
                      type="text" 
                      className="flex-grow p-3 bg-slate-50 border border-slate-200 rounded-xl font-bold text-sm outline-none focus:ring-2 focus:ring-purple-500/20"
                      placeholder="e.g. Rivian"
                      value={newMakeName}
                      onChange={e => setNewMakeName(e.target.value)}
                    />
                    <button 
                      type="button" 
                      onClick={handleAddMake}
                      className="bg-purple-600 text-white px-5 py-3 rounded-xl font-bold text-xs hover:bg-purple-700 active:scale-95 transition-all shadow-lg shadow-purple-500/10"
                    >
                      Add Make
                    </button>
                  </div>
                </div>

                <div className="space-y-4">
                  <label className="text-[10px] font-bold text-slate-400 uppercase">Add Model to Catalog</label>
                  <div className="space-y-2">
                    <select 
                      className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl font-bold text-sm outline-none focus:ring-2 focus:ring-blue-500/20"
                      value={selectedMakeForModel}
                      onChange={e => setSelectedMakeForModel(e.target.value)}
                    >
                      <option value="">Select Make...</option>
                      {makes.map(m => <option key={m} value={m}>{m}</option>)}
                    </select>
                    <div className="flex gap-2">
                      <input 
                        type="text" 
                        className="flex-grow p-3 bg-slate-50 border border-slate-200 rounded-xl font-bold text-sm outline-none focus:ring-2 focus:ring-blue-500/20"
                        placeholder="e.g. R1S"
                        value={newModelName}
                        onChange={e => setNewModelName(e.target.value)}
                      />
                      <button 
                        type="button" 
                        onClick={handleAddModel}
                        disabled={!selectedMakeForModel}
                        className="bg-blue-600 text-white px-5 py-3 rounded-xl font-bold text-xs hover:bg-blue-700 disabled:bg-slate-200 active:scale-95 transition-all shadow-lg shadow-blue-500/10"
                      >
                        Add Model
                      </button>
                    </div>
                  </div>
                </div>
              </div>

              <div className="pt-6 border-t border-slate-50 space-y-6">
                <div className="flex justify-between items-center">
                  <h4 className="text-[11px] font-bold text-slate-400 uppercase tracking-[0.2em]">Catalog Registry</h4>
                  <div className="relative">
                    <i className="fa-solid fa-magnifying-glass absolute left-3 top-1/2 -translate-y-1/2 text-[10px] text-slate-300"></i>
                    <input 
                      type="text" 
                      placeholder="Search makes or models..."
                      className="pl-8 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs font-bold outline-none focus:ring-2 focus:ring-blue-500/10 transition-all w-48"
                      value={catalogRegistrySearch}
                      onChange={e => setCatalogRegistrySearch(e.target.value)}
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 gap-4 max-h-[400px] overflow-y-auto pr-2 custom-scrollbar">
                  {filteredCatalogRegistry.map(make => (
                    <div key={make} className="group p-5 bg-[#f8fafc] border border-slate-100 rounded-2xl transition-all hover:bg-white hover:shadow-md hover:border-blue-100">
                      <div className="flex justify-between items-start mb-4">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 bg-white border border-slate-200 rounded-xl flex items-center justify-center text-slate-900 font-bold shadow-sm">
                            {make[0]}
                          </div>
                          <div>
                            <p className="font-bold text-slate-900">{make}</p>
                            <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{(modelsByMake[make] || []).length} Models Registered</p>
                          </div>
                        </div>
                        <button 
                          type="button"
                          onClick={(e) => requestDeleteMake(e, make)}
                          className="w-8 h-8 bg-white border border-slate-100 text-slate-300 rounded-lg flex items-center justify-center hover:text-rose-500 hover:border-rose-100 transition-all opacity-0 group-hover:opacity-100 shadow-sm"
                        >
                          <i className="fa-solid fa-trash-can text-xs"></i>
                        </button>
                      </div>
                      <div className="flex flex-wrap gap-2">
                        {(modelsByMake[make] || []).map(model => (
                          <div key={model} className="flex items-center gap-2 bg-white border border-slate-200 px-3 py-1.5 rounded-xl group/model hover:border-blue-200 transition-colors">
                            <span className="text-xs font-bold text-slate-600">{model}</span>
                            <button 
                              type="button"
                              onClick={(e) => requestDeleteModel(e, make, model)}
                              className="text-slate-300 hover:text-rose-500 transition-colors"
                            >
                              <i className="fa-solid fa-xmark text-[10px]"></i>
                            </button>
                          </div>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <div className="bg-white rounded-[2.5rem] p-8 md:p-12 border border-slate-100 shadow-xl space-y-10">
              <div className="space-y-2">
                <h3 className="text-xs font-bold text-slate-400 uppercase tracking-widest flex items-center gap-2">
                  <i className="fa-solid fa-palette text-pink-500"></i> Vehicle Color Management
                </h3>
                <p className="text-xs text-slate-500">Maintain the global registry of available vehicle colors for inventory listings.</p>
              </div>

              <div className="space-y-4 max-w-md">
                <label className="text-[10px] font-bold text-slate-400 uppercase">Register New Color</label>
                <div className="flex gap-2">
                  <input 
                    type="text" 
                    className="flex-grow p-3 bg-slate-50 border border-slate-200 rounded-xl font-bold text-sm outline-none focus:ring-2 focus:ring-pink-500/20"
                    placeholder="e.g. British Racing Green"
                    value={newColorName}
                    onChange={e => setNewColorName(e.target.value)}
                  />
                  <button 
                    type="button" 
                    onClick={handleAddColor}
                    className="bg-pink-600 text-white px-5 py-3 rounded-xl font-bold text-xs hover:bg-pink-700 active:scale-95 transition-all shadow-lg shadow-pink-500/10"
                  >
                    Add Color
                  </button>
                </div>
              </div>

              <div className="pt-6 border-t border-slate-50 space-y-6">
                <div className="flex justify-between items-center">
                  <h4 className="text-[11px] font-bold text-slate-400 uppercase tracking-[0.2em]">Color Database</h4>
                  <div className="relative">
                    <i className="fa-solid fa-magnifying-glass absolute left-3 top-1/2 -translate-y-1/2 text-[10px] text-slate-300"></i>
                    <input 
                      type="text" 
                      placeholder="Search colors..."
                      className="pl-8 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs font-bold outline-none focus:ring-2 focus:ring-pink-500/10 transition-all w-48"
                      value={colorRegistrySearch}
                      onChange={e => setColorRegistrySearch(e.target.value)}
                    />
                  </div>
                </div>

                <div className="flex flex-wrap gap-2 max-h-[250px] overflow-y-auto pr-2 custom-scrollbar p-1">
                  {filteredColorRegistry.map(color => (
                    <div key={color} className="group flex items-center gap-3 bg-slate-50 border border-slate-100 pl-4 pr-2 py-2 rounded-xl hover:bg-white hover:shadow-md hover:border-pink-100 transition-all">
                      <span className="text-xs font-bold text-slate-700 uppercase tracking-wide">{color}</span>
                      <button 
                        type="button"
                        onClick={(e) => requestDeleteColor(e, color)}
                        className="w-6 h-6 rounded-lg text-slate-300 hover:text-rose-500 hover:bg-rose-50 transition-all flex items-center justify-center opacity-0 group-hover:opacity-100"
                      >
                        <i className="fa-solid fa-xmark text-[10px]"></i>
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <div className="bg-white rounded-[2.5rem] p-8 md:p-12 border border-slate-100 shadow-xl space-y-10">
              <div className="space-y-2">
                <h3 className="text-xs font-bold text-slate-400 uppercase tracking-widest flex items-center gap-2">
                  <i className="fa-solid fa-truck-moving text-orange-500"></i> Transport
                </h3>
                <p className="text-xs text-slate-500">Manage companies and drivers that will handle vehicle logistics and deliveries.</p>
              </div>

              <div className="space-y-4 max-w-md">
                <label className="text-[10px] font-bold text-slate-400 uppercase">Register New Transport Partner</label>
                <div className="flex gap-2">
                  <input 
                    type="text" 
                    className="flex-grow p-3 bg-slate-50 border border-slate-200 rounded-xl font-bold text-sm outline-none focus:ring-2 focus:ring-orange-500/20"
                    placeholder="e.g. Rapid Haulers Inc."
                    value={newTransporterName}
                    onChange={e => setNewTransporterName(e.target.value)}
                  />
                  <button 
                    type="button" 
                    onClick={handleAddTransporter}
                    className="bg-orange-600 text-white px-5 py-3 rounded-xl font-bold text-xs hover:bg-orange-700 active:scale-95 transition-all shadow-lg shadow-orange-500/10"
                  >
                    Add Transporter
                  </button>
                </div>
              </div>

              <div className="pt-6 border-t border-slate-50 space-y-6">
                <div className="flex justify-between items-center">
                  <h4 className="text-[11px] font-bold text-slate-400 uppercase tracking-[0.2em]">Partner Registry</h4>
                  <div className="relative">
                    <i className="fa-solid fa-magnifying-glass absolute left-3 top-1/2 -translate-y-1/2 text-[10px] text-slate-300"></i>
                    <input 
                      type="text" 
                      placeholder="Search companies..."
                      className="pl-8 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs font-bold outline-none focus:ring-2 focus:ring-orange-500/10 transition-all w-48"
                      value={transporterRegistrySearch}
                      onChange={e => setTransporterRegistrySearch(e.target.value)}
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 max-h-[300px] overflow-y-auto pr-2 custom-scrollbar">
                  {filteredTransporterRegistry.map(transporter => (
                    <div key={transporter} className="group flex items-center justify-between bg-slate-50 border border-slate-100 p-4 rounded-2xl hover:bg-white hover:shadow-md hover:border-orange-100 transition-all">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 bg-white border border-slate-200 rounded-lg flex items-center justify-center text-orange-500 text-xs shadow-sm">
                          <i className="fa-solid fa-truck"></i>
                        </div>
                        <span className="text-xs font-bold text-slate-900 uppercase tracking-wide">{transporter}</span>
                      </div>
                      <button 
                        type="button"
                        onClick={(e) => requestDeleteTransporter(e, transporter)}
                        className="w-8 h-8 rounded-lg text-slate-300 hover:text-rose-500 hover:bg-rose-50 transition-all flex items-center justify-center opacity-0 group-hover:opacity-100"
                      >
                        <i className="fa-solid fa-trash-can text-xs"></i>
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <div className="bg-white rounded-[2.5rem] p-8 md:p-12 border border-slate-100 shadow-xl space-y-10">
              <div className="space-y-6">
                <h3 className="text-xs font-bold text-slate-400 uppercase tracking-widest flex items-center gap-2">
                  <i className="fa-solid fa-bolt text-blue-500"></i> Workflow Automation
                </h3>
                
                <div className="space-y-4">
                  <div className="flex items-center justify-between p-4 bg-slate-50 rounded-2xl">
                    <div>
                      <p className="font-bold text-sm text-slate-900">Auto-calculate Arrival ETAs</p>
                      <p className="text-xs text-slate-500">Enable algorithmic estimation for vehicle shop delivery.</p>
                    </div>
                    <button 
                      type="button" 
                      onClick={() => setDispatchSettings({...dispatchSettings, autoCalculateETA: !dispatchSettings.autoCalculateETA})}
                      className={`w-14 h-8 rounded-full transition-colors relative ${dispatchSettings.autoCalculateETA ? 'bg-blue-600' : 'bg-slate-300'}`}
                    >
                      <div className={`absolute top-1 w-6 h-6 bg-white rounded-full transition-all ${dispatchSettings.autoCalculateETA ? 'left-7' : 'left-1'}`}></div>
                    </button>
                  </div>

                  <div className="flex items-center justify-between p-4 bg-slate-50 rounded-2xl">
                    <div>
                      <p className="font-bold text-sm text-slate-900">Flag Overdue Pick-ups</p>
                      <p className="text-xs text-slate-500">Alert staff when vehicles are sitting paid but uncollected.</p>
                    </div>
                    <div className="flex items-center gap-3">
                      <input 
                        type="number" 
                        className="w-16 p-2 bg-white border border-slate-200 rounded-lg text-center text-sm font-bold" 
                        value={dispatchSettings.overdueAlertDays} 
                        onChange={e => setDispatchSettings({...dispatchSettings, overdueAlertDays: parseInt(e.target.value)})}
                      />
                      <span className="text-xs font-bold text-slate-400">DAYS</span>
                    </div>
                  </div>
                </div>
              </div>

              <div className="space-y-6">
                <h3 className="text-xs font-bold text-slate-400 uppercase tracking-widest flex items-center gap-2">
                  <i className="fa-solid fa-shield-halved text-emerald-500"></i> Compliance & Requirements
                </h3>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <button 
                    type="button"
                    onClick={() => setDispatchSettings({...dispatchSettings, requireKeysForDelivery: !dispatchSettings.requireKeysForDelivery})}
                    className={`p-5 rounded-2xl border-2 text-left transition-all ${dispatchSettings.requireKeysForDelivery ? 'border-emerald-500 bg-emerald-50' : 'border-slate-100 bg-white hover:border-slate-200'}`}
                  >
                     <i className="fa-solid fa-key mb-3 text-lg text-slate-300"></i>
                     <p className="font-bold text-sm text-slate-900">Hard-Require Keys</p>
                     <p className="text-[10px] text-slate-500 uppercase font-bold mt-1">For Delivery Status</p>
                  </button>

                  <button 
                    type="button"
                    onClick={() => setDispatchSettings({...dispatchSettings, requireTitleForReady: !dispatchSettings.requireTitleForReady})}
                    className={`p-5 rounded-2xl border-2 text-left transition-all ${dispatchSettings.requireTitleForReady ? 'border-emerald-500 bg-emerald-50' : 'border-slate-100 bg-white hover:border-slate-200'}`}
                  >
                     <i className="fa-solid fa-id-card mb-3 text-lg text-slate-300"></i>
                     <p className="font-bold text-sm text-slate-900">Hard-Require Title</p>
                     <p className="text-[10px] text-slate-500 uppercase font-bold mt-1">For Ready-to-Sell Status</p>
                  </button>
                </div>
              </div>

              <div className="pt-8 flex gap-4">
                <button type="button" onClick={() => setView('dashboard')} className="flex-1 py-4 bg-slate-100 text-slate-600 rounded-2xl font-bold hover:bg-slate-200 transition-all">Discard</button>
                <button type="submit" disabled={isSavingSettings} className="flex-1 py-4 bg-blue-600 text-white rounded-2xl font-bold hover:bg-blue-700 transition-all shadow-xl shadow-blue-500/10 flex items-center justify-center gap-2">
                  {isSavingSettings ? <i className="fa-solid fa-spinner fa-spin"></i> : <i className="fa-solid fa-cloud-arrow-up"></i>}
                  Save Configuration
                </button>
              </div>
            </div>
          </form>
        </div>
      </div>
    );
  }

  if (view === 'detail' && activeVehicle) {
    const currentMakeModels = modelsByMake[activeVehicle.make] || [];
    const currentStatusRank = STATUS_PROGRESSION[activeVehicle.paymentStatus] || 0;

    return (
      <div className="bg-[#f8fafc] min-h-screen text-slate-900 p-6 md:p-10 animate-in fade-in duration-500">
        {isMediaManagerOpen && (
          <div className="fixed inset-0 z-[120] flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-md animate-in fade-in duration-300">
            <div className="bg-white w-full max-w-2xl rounded-[2.5rem] shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[90vh]">
              <div className="p-8 border-b border-slate-50 flex justify-between items-center bg-slate-50/30">
                <h3 className="text-2xl font-bold flex items-center gap-3">
                  <i className="fa-solid fa-photo-film text-purple-500"></i> Manage Gallery
                </h3>
                <button onClick={() => setIsMediaManagerOpen(false)} className="w-10 h-10 rounded-full bg-white border border-slate-200 flex items-center justify-center text-slate-400 hover:text-slate-900 transition-all active:scale-95 shadow-sm">
                  <i className="fa-solid fa-xmark"></i>
                </button>
              </div>
              <div className="p-8 overflow-y-auto space-y-8">
                <div className="space-y-4">
                  <label className="text-xs font-bold text-slate-400 uppercase tracking-widest">Upload New Photos</label>
                  <div onClick={triggerFileUpload} className="group border-2 border-dashed border-slate-200 rounded-[2rem] p-10 flex flex-col items-center justify-center bg-slate-50 hover:bg-purple-50 hover:border-purple-300 transition-all cursor-pointer">
                    <div className="w-16 h-16 bg-white rounded-2xl flex items-center justify-center shadow-sm mb-4 border border-slate-100 group-hover:scale-110 transition-transform">
                      <i className="fa-solid fa-cloud-arrow-up text-purple-600 text-2xl"></i>
                    </div>
                    <p className="font-bold text-slate-900 mb-1">Select files from your computer</p>
                    <p className="text-sm text-slate-500">JPG, PNG or GIF. Max 10MB each.</p>
                    <input type="file" ref={fileInputRef} className="hidden" accept="image/*" multiple onChange={handleFileChange} />
                  </div>
                </div>
                <div className="space-y-4">
                  <label className="text-xs font-bold text-slate-400 uppercase tracking-widest">Current Media ({activeVehicle.images.length})</label>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    {activeVehicle.images.map((img, idx) => (
                      <div key={idx} className="group relative aspect-video rounded-2xl overflow-hidden border border-slate-100 shadow-sm bg-slate-50">
                        <img src={img} className="w-full h-full object-cover" alt="" />
                        <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                          <button onClick={() => handleRemoveMedia(idx)} className="bg-rose-500 text-white w-10 h-10 rounded-full flex items-center justify-center shadow-lg hover:bg-rose-600 active:scale-90 transition-all">
                            <i className="fa-solid fa-trash-can text-sm"></i>
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
              <div className="p-8 bg-slate-50 border-t border-slate-100 flex justify-end">
                <button onClick={() => setIsMediaManagerOpen(false)} className="bg-slate-900 text-white px-10 py-4 rounded-2xl font-bold text-sm hover:bg-slate-800 transition-all active:scale-95 shadow-xl">Done</button>
              </div>
            </div>
          </div>
        )}
        {isLightboxOpen && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-900/95 backdrop-blur-xl animate-in fade-in duration-300">
            <div className="absolute inset-0 cursor-zoom-out" onClick={closeLightbox}></div>
            <div className="absolute top-8 right-8 flex gap-4 z-[110]">
               <button onClick={handleZoomOut} className="w-12 h-12 rounded-full bg-white/10 hover:bg-white/20 text-white flex items-center justify-center transition-all border border-white/10 active:scale-95">
                <i className="fa-solid fa-magnifying-glass-minus"></i>
              </button>
              <button onClick={handleZoomIn} className="w-12 h-12 rounded-full bg-white/10 hover:bg-white/20 text-white flex items-center justify-center transition-all border border-white/10 active:scale-95">
                <i className="fa-solid fa-magnifying-glass-plus"></i>
              </button>
              <button onClick={closeLightbox} className="w-12 h-12 rounded-full bg-white/10 hover:bg-white/20 text-white flex items-center justify-center transition-all border border-white/10 active:scale-95">
                <i className="fa-solid fa-xmark text-lg"></i>
              </button>
            </div>
            <div className="relative z-[105] max-w-[90vw] max-h-[80vh] overflow-hidden rounded-3xl shadow-2xl transition-transform duration-300 flex items-center justify-center bg-black/20" style={{ transform: `scale(${zoomLevel})` }}>
              <img src={activeVehicle.images[activeImageIndex]} className="max-w-full max-h-full object-contain pointer-events-none" alt="Enlarged Vehicle" />
            </div>
          </div>
        )}
        <div className="max-w-[1200px] mx-auto space-y-4 pb-20">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-6">
            <button onClick={() => setView('dashboard')} className="group bg-white border border-slate-200 text-slate-700 px-6 py-3 rounded-2xl font-bold text-sm flex items-center gap-2 hover:bg-slate-50 transition-all shadow-sm active:scale-95">
              <i className="fa-solid fa-arrow-left group-hover:-translate-x-1 transition-transform"></i> Back to Dashboard
            </button>
            <div className="flex gap-3">
              <button onClick={handleSaveChanges} className="bg-blue-600 text-white px-8 py-3 rounded-2xl font-bold text-sm hover:bg-blue-700 transition-all shadow-lg shadow-blue-500/10 active:scale-95">Save Changes</button>
            </div>
          </div>
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            <div className="lg:col-span-8 space-y-6">
              <div className="bg-white rounded-[2.5rem] p-8 border border-slate-100 shadow-sm space-y-6">
                <div className="flex flex-col sm:flex-row justify-between items-start gap-6">
                  <div className="w-full space-y-2">
                    <div className="flex items-center flex-wrap gap-8 mb-1">
                      <div className="flex flex-col">
                        <input 
                          type="text" 
                          placeholder="Year"
                          className="text-2xl font-serif font-bold text-slate-900 bg-transparent outline-none w-[70px] border-b-2 border-transparent focus:border-blue-200 transition-all" 
                          value={activeVehicle.year} 
                          onChange={(e) => handleEditVehicle('year', e.target.value)} 
                        />
                      </div>
                      <div className="flex flex-col">
                        <SearchableSelect value={activeVehicle.make} options={makes} placeholder="Make" onChange={(newMake) => { handleEditVehicle('make', newMake); if (modelsByMake[newMake]) { handleEditVehicle('model', modelsByMake[newMake][0]); } }} />
                      </div>
                      <div className="flex flex-col">
                        <SearchableSelect value={activeVehicle.model} options={currentMakeModels} placeholder="Model" onChange={(newModel) => handleEditVehicle('model', newModel)} />
                      </div>
                      <div className="flex flex-col">
                        <SearchableSelect value={activeVehicle.color} options={colors} placeholder="Color" onChange={(newColor) => handleEditVehicle('color', newColor)} />
                      </div>
                    </div>
                    <div className="flex flex-wrap items-center gap-3">
                      <div className="flex items-center bg-[#f8fafc] px-3 py-1.5 rounded-lg border border-slate-100">
                        <span className="text-[9px] font-bold text-slate-400 uppercase mr-3 tracking-wider">VIN</span>
                        <input type="text" className="text-slate-500 font-mono tracking-widest text-[11px] bg-transparent outline-none min-w-[120px]" value={activeVehicle.vin} onChange={(e) => handleEditVehicle('vin', e.target.value.toUpperCase())} />
                      </div>
                      <div className="flex items-center bg-[#f8fafc] px-3 py-1.5 rounded-lg border border-slate-100">
                        <span className="text-[9px] font-bold text-slate-400 uppercase mr-3 tracking-wider">LOT</span>
                        <input type="text" className="text-slate-500 font-mono text-[11px] bg-transparent outline-none min-w-[90px]" value={activeVehicle.lotNumber} onChange={(e) => handleEditVehicle('lotNumber', e.target.value)} />
                      </div>
                      <div className="flex items-center bg-[#f8fafc] px-3 py-1.5 rounded-lg border border-slate-100">
                        <span className="text-[9px] font-bold text-slate-400 uppercase mr-3 tracking-wider">DESTINATION</span>
                        <select 
                          className={`font-bold text-[11px] bg-transparent outline-none min-w-[120px] focus:text-blue-600 transition-colors appearance-none pr-4 ${activeVehicle.destination ? 'text-slate-500' : 'text-slate-300'}`}
                          value={activeVehicle.destination}
                          onChange={(e) => handleEditVehicle('destination', e.target.value)}
                        >
                          <option value="" disabled hidden>Add DESTINATION</option>
                          {DESTINATIONS.map(d => <option key={d} value={d} className="text-slate-900">{d}</option>)}
                        </select>
                      </div>
                    </div>
                  </div>
                  <div className="min-w-[180px]">
                    <p className="text-[9px] font-bold text-slate-400 uppercase tracking-widest mb-1">WORKFLOW STATE</p>
                    <div className="relative">
                      <select className="w-full bg-[#eff6ff] text-blue-600 px-5 py-2 rounded-full font-bold text-xs shadow-sm outline-none border-none cursor-pointer appearance-none" value={activeVehicle.paymentStatus} onChange={(e) => handleEditVehicle('paymentStatus', e.target.value)}>
                        <option value="Pending">Pending</option>
                        <option value="Paid">Paid</option>
                        <option value="Picked Up">Picked Up</option>
                        <option value="Delivered">Delivered</option>
                        <option value="Fixing">Fixing</option>
                        <option value="Ready to Sell">Ready to Sell</option>
                      </select>
                    </div>
                  </div>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-12 gap-8 pt-8 border-t border-slate-50">
                  <div className="sm:col-span-5 space-y-4">
                    <div className="space-y-2">
                        <p className="text-[9px] font-bold text-slate-400 uppercase tracking-widest">FINANCIAL STATUS & COST</p>
                        <div className="flex items-center">
                        <span className="text-slate-300 font-bold text-xl mr-1">$</span>
                        <input type="number" className="font-bold text-3xl text-slate-900 bg-transparent outline-none w-full" value={activeVehicle.price} onChange={(e) => handleEditVehicle('price', parseInt(e.target.value) || 0)} />
                        </div>
                    </div>

                    <div className="space-y-2 pt-2">
                      <p className="text-[9px] font-bold text-slate-400 uppercase tracking-widest">Category</p>
                      <select 
                        className="w-full bg-slate-50 text-slate-900 px-5 py-3 rounded-xl font-bold text-xs border border-slate-100 outline-none focus:ring-2 focus:ring-blue-500/20 appearance-none cursor-pointer"
                        value={activeVehicle.category}
                        onChange={(e) => handleEditVehicle('category', e.target.value)}
                      >
                        {CATEGORIES.map(cat => <option key={cat} value={cat}>{cat}</option>)}
                      </select>
                    </div>

                    <div className="space-y-3 pt-2 border-t border-slate-50 mt-4">
                      <p className="text-[9px] font-bold text-slate-400 uppercase tracking-widest">Fuel Type</p>
                      <div className="flex flex-wrap gap-2">
                        {['Gas', 'Hybrid', 'EV', 'Diesel', 'Other'].map((f) => (
                          <button
                            key={f}
                            type="button"
                            onClick={() => handleEditVehicle('fuelType', f)}
                            className={`px-4 py-2 rounded-xl text-[10px] font-bold transition-all border ${
                              activeVehicle.fuelType === f
                                ? 'bg-blue-600 border-blue-700 text-white'
                                : 'bg-slate-50 text-slate-400 border-slate-100'
                            }`}
                          >
                            {f}
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>
                  <div className="sm:col-span-7 space-y-2">
                    <p className="text-[9px] font-bold text-slate-400 uppercase tracking-widest">OWNERSHIP DOCS</p>
                    <div className="flex flex-col gap-4">
                      <div className="flex items-center gap-4">
                        <div className="flex flex-col gap-1 flex-1">
                          <label className="text-[9px] font-bold text-slate-400 uppercase mb-1">TITLE STATUS</label>
                          <select className={`w-full text-xs font-bold p-2 px-4 rounded-xl border transition-all cursor-pointer outline-none appearance-none ${activeVehicle.hasTitle === 'YES' ? 'bg-[#f0fdf4] text-emerald-600 border-emerald-100' : activeVehicle.hasTitle === 'TBO' ? 'bg-[#eef2ff] text-indigo-600 border-indigo-100' : 'bg-rose-50 text-rose-500 border-rose-100'}`} value={activeVehicle.hasTitle} onChange={(e) => handleEditVehicle('hasTitle', e.target.value)}>
                            <option value="YES">YES</option>
                            <option value="NO">NO</option>
                            <option value="TBO">TBO</option>
                          </select>
                        </div>
                        <div className="flex flex-col gap-1 flex-1">
                          <label className="text-[9px] font-bold text-slate-400 uppercase mb-1">KEY STATUS</label>
                          <select className={`w-full text-xs font-bold p-2 px-4 rounded-xl border transition-all cursor-pointer outline-none appearance-none ${activeVehicle.hasKeys ? 'bg-[#f0fdf4] text-emerald-600 border-emerald-100' : 'bg-rose-50 text-rose-500 border-rose-100'}`} value={activeVehicle.hasKeys ? 'true' : 'false'} onChange={(e) => handleEditVehicle('hasKeys', e.target.value === 'true')}>
                            <option value="true">YES</option>
                            <option value="false">NO</option>
                          </select>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-[#f8fafc] min-h-screen text-slate-900 px-6 py-8 md:px-12 md:py-10">
      <div className="max-w-[1400px] mx-auto mb-10 flex flex-col md:flex-row justify-between items-start md:items-end gap-6">
        <div className="space-y-1">
          <div className="flex items-center gap-4">
            <h1 className="text-4xl font-serif font-bold text-[#1e293b] tracking-tight leading-tight">Business Overview</h1>
            <div className="flex gap-2">
              <Link to="/accountant" className="bg-emerald-50 text-emerald-600 px-4 py-2 rounded-xl font-bold text-xs hover:bg-emerald-100 border border-emerald-100 flex items-center gap-2">
                <i className="fa-solid fa-calculator"></i> Accountant Hub
              </Link>
              <button onClick={() => setView('settings')} className="bg-white border border-slate-200 text-slate-600 px-4 py-2 rounded-xl font-bold text-xs hover:bg-slate-50 flex items-center gap-2">
                <i className="fa-solid fa-sliders"></i> Dispatch Settings
              </button>
            </div>
          </div>
        </div>
        <div className="flex items-center gap-4 w-full md:w-auto">
          <input type="text" placeholder="Search VIN or Lot#" className="w-full pl-4 pr-4 py-3.5 rounded-2xl border border-slate-200 bg-white outline-none shadow-sm text-[13px] font-medium" value={search} onChange={(e) => setSearch(e.target.value)} />
          <button onClick={handleAddVehicle} className="bg-[#2563eb] text-white px-8 py-3.5 rounded-2xl font-bold text-[14px] flex items-center gap-2.5 hover:bg-blue-700 transition-all shadow-xl shadow-blue-500/10 whitespace-nowrap">
            <i className="fa-solid fa-plus text-xs"></i> New Arrival
          </button>
        </div>
      </div>

      <div className="max-w-[1400px] mx-auto grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
        <div className="lg:col-span-12 bg-white rounded-[2.5rem] p-8 border border-slate-100 shadow-sm flex flex-col h-full">
          <div className="space-y-3 flex-grow overflow-y-auto">
            {paginatedArrivals.map((car) => (
              <div key={car.id} className="flex items-center group cursor-pointer hover:bg-slate-50/80 px-5 py-4 rounded-2xl transition-all border border-transparent hover:border-slate-100" onClick={() => handleOpenDetail(car)}>
                <div className="flex-grow flex flex-col md:flex-row md:items-center justify-between gap-2">
                  <div className="space-y-0.5">
                    <p className="font-bold text-[16px] text-slate-900 leading-tight tracking-tight">
                      {car.year || 'Year'} {car.make || 'Make'} {car.model || 'Model'} {car.trim ? `• ${car.trim}` : ''} {car.color ? `• ${car.color}` : ''}
                    </p>
                    <div className="flex flex-wrap items-center gap-2" onClick={e => e.stopPropagation()}>
                      <span className="text-[11px] text-slate-400 font-mono font-medium">{car.vin || 'VIN REQUIRED'}</span>
                      <select className="appearance-none outline-none border-none pl-6 pr-6 py-0.5 rounded-full text-[10px] font-bold bg-slate-100 text-slate-500 cursor-pointer" value={car.paymentStatus} onChange={e => updatePaymentStatus(e, car.id)}>
                        <option value="Paid">Paid</option>
                        <option value="Picked Up">Picked Up</option>
                        <option value="Delivered">Delivered</option>
                        <option value="Fixing">Fixing</option>
                        <option value="Ready to Sell">Ready to Sell</option>
                        <option value="Pending">Pending</option>
                      </select>
                    </div>
                  </div>
                  <div className="flex items-center gap-6 md:pl-4">
                    <p className="font-bold text-[16px] text-slate-900 tracking-tight shrink-0">${car.price.toLocaleString()}</p>
                    <div className="w-8 h-8 rounded-full flex items-center justify-center bg-slate-50 group-hover:bg-blue-600 group-hover:text-white transition-all">
                      <i className="fa-solid fa-chevron-right text-[10px]"></i>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default DispatchPage;
